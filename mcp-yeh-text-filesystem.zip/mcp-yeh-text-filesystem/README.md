mcp-yeh-text-filesystem - 編碼感知的 MCP 文字檔伺服器

作者: HsiupoYeh
版本: v20261027a

以 MCP（stdio）提供檔案工具，專門處理非 UTF-8 編碼的文字檔：
Big5 / CP950 / GBK / GB18030 / Shift_JIS / EUC-KR / Windows-125x /
ISO-8859-x / UTF-16(LE/BE) / UTF-8(含 BOM)。

讀進來的內容一律以 UTF-8 交給模型；寫回去時還原原本的編碼、BOM 與換行風格。
規格見 SPEC.md，設計說明見 docs/DESIGN.md。

建置環境:
- Go 1.26.0 以上（go.mod 宣告 go 1.26.0；go-sdk v1.8.0 最低需求為 Go 1.25）
- 依賴已放入 src/vendor，可完全離線編譯

功能:
- 19 個 MCP 工具：read_file、read_files、write_file、edit_file、
  list_dir、tree_view、find_files、search_content、inspect_encoding、
  transcode、fix_line_endings、fix_bom、file_stat、copy_path、move_path、
  delete_path、make_dir、list_roots、supported_encodings
- 讀檔自動偵測編碼，可分段讀取
- 寫檔保留原編碼、BOM、換行風格；可用 expectedHash 防止覆蓋他人變更
- 寫入類工具支援 dryRun 預覽
- 所有路徑限制在允許根目錄內，符號連結會先解析再比對
- 執行檔為 Console 子系統（stdio MCP 伺服器，不使用 GUI 子系統）
- 圖示與 manifest 以 src/rsrc.syso 嵌入

目錄結構:
  mcp-yeh-text-filesystem/
  ├── src/
  │   ├── main.go         ← 原始碼入口（慣例使用 main.go 作為固定名稱）
  │   ├── internal/       ← guard、enc、fileio、tools 套件
  │   ├── go.mod          ← 模組定義（記錄套件版本，有助追蹤與重建環境）
  │   ├── go.sum          ← 依賴 hash 鎖定（vendor 時產生）
  │   ├── vendor/         ← 所有依賴原始碼（離線編譯用；完全離線、可分發；遵守來源版權）
  │   │   ├── github.com/
  │   │   ├── golang.org/
  │   │   └── modules.txt
  │   ├── rsrc.syso       ← 資源檔（圖示 + manifest，用 rsrc 工具產生）
  │   └── main.manifest   ← DPI awareness + 視覺樣式設定（嵌入 rsrc.syso）
  ├── icon/
  │   └── mcp-yeh-text-filesystem.ico  ← 應用程式圖示
  ├── exe/
  │   └── mcp-yeh-text-filesystem.exe  ← 編譯後的執行檔
  ├── build.bat           ← 編譯腳本
  ├── backup/             ← 手動備份（取代 Git）
  ├── docs/
  │   └── DESIGN.md       ← 設計說明
  ├── test/
  │   └── probe.mjs       ← MCP 端對端檢查
  ├── SPEC.md             ← 行為規格
  ├── LICENSE
  └── README.md           ← 專案說明

編譯方式:
  build.bat
  或
  cd src && go build -mod=vendor -trimpath -ldflags="-s -w" -o ..\exe\mcp-yeh-text-filesystem.exe

編譯輸出:
  exe/mcp-yeh-text-filesystem.exe（含圖示 + manifest；Console 子系統）

產生 rsrc.syso:
  rsrc -ico icon/mcp-yeh-text-filesystem.ico -manifest src/main.manifest -o src/rsrc.syso

MCP 部署範例:
  "mcp": {
    "servers": {
      "mcp-yeh-text-filesystem": {
        "type": "local",
        "command": ["./mcp-yeh-text-filesystem/exe/mcp-yeh-text-filesystem.exe", "."],
        "codemode": false
      }
    }
  }

- 參數是允許存取的根目錄，可給多個，`.` 代表專案根。
- 不給參數時讀環境變數 MCP_YEH_TEXT_FILESYSTEM_ROOTS（以 `;` 分隔）。
- 兩者皆空時拒絕啟動，並在 stderr 說明（exit code 2）。
- 根目錄之外的路徑一律拒絕，符號連結會先解析再比對。

驗證:
  cd src && go test ./...     # 編碼、路徑守衛、檔案讀寫
  node test\probe.mjs         # 46 項 MCP 端對端檢查

2026-10-27 於本機（Windows、Go 1.27.3、Node 24）實測：go test 全部通過，
端對端 46 項全過。執行檔 SHA-256 為
015910AB6ADB16CD4B11F19181549E7199DB29C77010A39B173BE8D1E19861DF。

相依套件管理:
  相依已 go mod vendor 進 src/vendor，編譯不連網。升級相依時：
  cd src
  go get <module>@<version>
  go mod tidy
  go mod vendor

授權:
  MIT，見 LICENSE。第三方相依套件：
  - github.com/modelcontextprotocol/go-sdk — Apache-2.0 / MIT
  - github.com/google/jsonschema-go — Apache-2.0
  - github.com/wlynxg/chardet — MIT
  - golang.org/x/text — BSD-3-Clause

本專案為獨立實作，未使用任何 GPL 程式碼。
