# AGENTS.md

檔案操作一律用 mcp-yeh-text-filesystem MCP（`read_file`、`write_file`、`edit_file`、`search_content` 等），
19 個工具涵蓋讀寫、搜尋、編碼轉換與檔案操作。

不用 shell 讀寫檔案（`Get-Content`／`Out-File`）。

寫入前先確認編碼與換行：`read_file` 的回傳已含 `encoding`、`bom`、`eol`、`hash`；
覆寫既有檔案時把 `hash` 當 `expectedHash` 傳回去。

每次開啟專案，先確認 mcp-yeh-text-filesystem 可用（`list_roots` 能正常回傳）；不可用就回報，不要默默改用其他方式。
