# 設計

## 分層

```
src/main.go         進入點：解析根目錄、啟動 stdio 傳輸
internal/guard      路徑守衛：絕對化、解析符號連結、比對白名單
internal/enc        編碼：偵測、解碼成 UTF-8、編回首選編碼、BOM
internal/fileio     檔案語意：讀取範圍、覆寫、局部取代、diff、雜湊
internal/tools      MCP 工具：輸入結構、處理函式、輸出整形
```

相依方向單向：`tools → fileio → enc`，`tools → guard`。`enc` 與 `guard` 不認識彼此。

## 讀取流程

1. `guard.Resolve` 把路徑絕對化，對最長的既有前綴呼叫 `EvalSymlinks`，再比對白名單。
2. 讀入原始位元組；先看 BOM，再看是否為合法 UTF-8，最後才交給統計式偵測器。
3. 依偵測到的編碼解碼成 UTF-8，換行統一成 `\n` 再輸出。
4. 回傳 `hash`（正規化文字的前 8 位元 SHA-256）、`encoding`、`bom`、`eol`、行號範圍。

模型看到的一律是 `\n`，所以 `oldText` 不會因為檔案是 CRLF 而對不上。

## 寫入流程

1. 既有檔案先讀一次，取得編碼、BOM、換行風格；`expectedHash` 不符就中止（`hash_mismatch`）。
2. 內容正規化成 `\n`，再依目標換行風格展開。
3. 編碼後寫回。新檔預設 UTF-8、無 BOM、LF。
4. `dryRun` 只計算結果，不落地，用來預覽。

## 錯誤

錯誤一律以 `kind: message` 的單行文字回傳，`kind` 固定為
`path_outside_roots`、`not_found`、`is_directory`、`encoding_unknown`、
`hash_mismatch`、`invalid_argument`、`io_error`。

## 為何不用 `filepath.Walk` 直接信任

`Walk` 會跟隨目錄項，但不保證每個子路徑都在白名單內（例如符號連結）。
所有真正落地的操作都先經過 `Resolve`，包含複製與搬移的目的地。

## 相依

- `modelcontextprotocol/go-sdk`：MCP 協定與 JSON-RPC。
- `jsonschema-go`：輸入結構描述。無參數工具明確給 `{"type":"object","properties":{}}`，
  避免嚴格驗證的 OpenAI 相容 provider 因缺 `properties` 而整批失敗。
- `wlynxg/chardet`：統計式偵測（Big5、GBK、Shift_JIS 等）。
- `x/text`：實際的編解碼表。

## 測試

- `internal/enc`：九種編碼來回、BOM、偵測、別名、清單可用性。
- `internal/guard`：範圍內、範圍外、根目錄不存在、重複根目錄收斂。
- `internal/fileio`：編碼保留、換行與 BOM 繼承、hash 防護、dryRun、行範圍。
- `test/probe.mjs`：以真實 stdio 連線跑 46 項端對端檢查（工具數量、schema、編碼來回、
  錯誤情境、目錄操作、白名單）。
