# mcp-yeh-text-filesystem — 規格

本文件只描述「行為」，不含任何第三方實作。程式依本規格獨立撰寫。

## 目的

一個 MCP（stdio）檔案伺服器，專門處理**非 UTF-8 編碼的文字檔**：
Big5 / CP950 / GBK / GB18030 / Shift_JIS / EUC-KR / Windows-125x /
ISO-8859-x / UTF-16(LE/BE) / UTF-8(含 BOM)。

重點：讀進來的內容一律以 UTF-8 交給模型；寫回去時還原原本的編碼、
BOM 與換行風格。**不提示使用者改用其他工具。**

## 執行方式

```
mcp-yeh-text-filesystem.exe [允許目錄 ...]
```

- 參數是允許存取的根目錄（可多個）。
- 無參數時讀環境變數 `MCP_YEH_TEXT_FILESYSTEM_ROOTS`（以 `;` 分隔）。
- 兩者皆空 → 拒絕啟動並在 stderr 說明。
- 所有路徑必須落在允許目錄內（含符號連結解析後的實際位置）。

## 工具（全部使用 JSON 物件作為輸入）

| 工具 | 用途 |
|---|---|
| `read_file` | 讀檔，自動偵測編碼，回傳 UTF-8 內容 |
| `read_files` | 一次讀多檔 |
| `write_file` | 新建或整份覆寫，保留或指定編碼 |
| `edit_file` | 局部取代，回傳 diff |
| `list_dir` | 列出目錄 |
| `tree_view` | 樹狀列出 |
| `find_files` | 依檔名找檔 |
| `search_content` | 依內容搜尋 |
| `inspect_encoding` | 只回報編碼資訊 |
| `transcode` | 轉換整檔編碼 |
| `fix_line_endings` | 統一行尾 |
| `fix_bom` | 加上／移除 BOM |
| `file_stat` | 檔案資訊 |
| `copy_path` | 複製 |
| `move_path` | 搬移／改名 |
| `delete_path` | 刪除 |
| `make_dir` | 建立目錄 |
| `list_roots` | 列出允許目錄 |
| `supported_encodings` | 列出支援的編碼 |

## 輸出原則

- 一律精簡 JSON，只放用得到的欄位。
- 讀檔回傳：`text`、`encoding`、`bom`、`eol`、`hash`、`startLine`、`endLine`、`totalLines`、`bytes`。
- 不回傳任何建議改用其他工具的訊息。
- 錯誤回傳 `{"error": "...", "kind": "..."}`，`kind` 為
  `path_outside_roots`、`not_found`、`is_directory`、`encoding_unknown`、
  `hash_mismatch`、`invalid_argument`、`io_error` 之一。

## 編碼規則

1. 有 BOM → 以 BOM 為準。
2. 無 BOM 且位元組是合法 UTF-8 → `utf-8`。
3. 其餘 → 交給偵測器；信心不足時仍回報偵測結果並附上 `confidence`。
4. 寫檔時若未指定 `encoding`：沿用讀到的編碼；新檔預設 `utf-8`。
5. 寫檔時若未指定 `bom`：沿用原檔；新檔不加。
6. 換行風格（`lf` / `crlf`）沿用原檔；可用參數覆寫。

## 安全

- 路徑一律先解析成絕對路徑，再比對是否位於允許目錄之下。
- 不跟隨指向允許範圍外的符號連結。
- `delete_path` 只刪檔案與空目錄，不遞迴刪除。
- 每個寫入類工具都可用 `dryRun` 預覽。

## 授權

本專案為獨立實作。使用的相依套件僅限寬鬆授權：
`golang.org/x/text`（BSD-3）、`github.com/wlynxg/chardet`（MIT）、
`github.com/modelcontextprotocol/go-sdk`（Apache-2.0/MIT）、
`github.com/google/jsonschema-go`（Apache-2.0）。
