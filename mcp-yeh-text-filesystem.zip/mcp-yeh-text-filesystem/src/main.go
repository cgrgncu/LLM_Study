// Command mcp-yeh-text-filesystem serves encoding-aware text file tools over MCP stdio.
package main

import (
	"context"
	"log"
	"os"
	"os/signal"
	"strings"
	"syscall"

	"github.com/modelcontextprotocol/go-sdk/mcp"

	"mcp-yeh-text-filesystem/internal/guard"
	"mcp-yeh-text-filesystem/internal/tools"
)

const version = "v20261027a"

func main() {
	log.SetOutput(os.Stderr)
	log.SetFlags(0)

	roots := os.Args[1:]
	if len(roots) == 0 {
		if env := strings.TrimSpace(os.Getenv("MCP_YEH_TEXT_FILESYSTEM_ROOTS")); env != "" {
			for _, r := range strings.Split(env, string(os.PathListSeparator)) {
				if s := strings.TrimSpace(r); s != "" {
					roots = append(roots, s)
				}
			}
		}
	}
	if len(roots) == 0 {
		log.Printf("mcp-yeh-text-filesystem: no roots given; pass directories as arguments or set MCP_YEH_TEXT_FILESYSTEM_ROOTS")
		os.Exit(2)
	}

	g, err := guard.New(roots)
	if err != nil {
		log.Printf("mcp-yeh-text-filesystem: %v", err)
		os.Exit(2)
	}
	log.Printf("mcp-yeh-text-filesystem %s ready; roots: %s", version, strings.Join(g.Roots(), string(os.PathListSeparator)))

	ctx, stop := signal.NotifyContext(context.Background(), os.Interrupt, syscall.SIGTERM)
	defer stop()

	srv := tools.Register(g, version)
	if err := srv.Run(ctx, &mcp.StdioTransport{}); err != nil {
		log.Printf("mcp-yeh-text-filesystem: %v", err)
		os.Exit(1)
	}
}
