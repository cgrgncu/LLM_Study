// Package fileio implements encoding-preserving text reads and writes.
package fileio

import (
	"crypto/sha256"
	"encoding/hex"
	"fmt"
	"os"
	"path/filepath"
	"strings"

	"mcp-yeh-text-filesystem/internal/enc"
)

// Error carries a machine-readable kind for tool responses.
type Error struct {
	Kind string
	Msg  string
}

func (e *Error) Error() string { return e.Msg }

func fail(kind, format string, a ...any) *Error {
	return &Error{Kind: kind, Msg: fmt.Sprintf(format, a...)}
}

// ReadOptions controls where in the file the read starts and stops.
type ReadOptions struct {
	Offset   int
	Limit    int
	MaxChars int
	Encoding string
}

// ReadResult mirrors the tool output of read_file.
type ReadResult struct {
	Path       string `json:"path"`
	Text       string `json:"text"`
	Encoding   string `json:"encoding"`
	BOM        bool   `json:"bom"`
	EOL        string `json:"eol"`
	Hash       string `json:"hash"`
	StartLine  int    `json:"startLine"`
	EndLine    int    `json:"endLine"`
	TotalLines int    `json:"totalLines"`
	Bytes      int    `json:"bytes"`
	Confidence int    `json:"confidence,omitempty"`
}

// Read decodes a file to UTF-8 and returns the requested line range.
func Read(path string, o ReadOptions) (*ReadResult, error) {
	st, err := os.Stat(path)
	if err != nil {
		return nil, describe(err, path)
	}
	if st.IsDir() {
		return nil, fail("is_directory", "%s is a directory", path)
	}
	raw, err := os.ReadFile(path)
	if err != nil {
		return nil, describe(err, path)
	}

	info := enc.Detect(raw)
	name := info.Name
	if o.Encoding != "" {
		if !enc.Valid(o.Encoding) {
			return nil, fail("encoding_unknown", "unsupported encoding %q", o.Encoding)
		}
		name = o.Encoding
	}
	if !enc.Valid(name) {
		return nil, fail("encoding_unknown", "detected encoding %q is not supported; pass encoding explicitly", name)
	}
	text, err := enc.Decode(raw, name)
	if err != nil {
		return nil, fail("encoding_unknown", "cannot decode %s as %s: %v", path, name, err)
	}

	eol := DetectEOL(text)
	text = strings.ReplaceAll(text, "\r\n", "\n")
	text = strings.ReplaceAll(text, "\r", "\n")

	lines := strings.Split(text, "\n")
	// A trailing newline yields a final empty element; keep line numbers natural.
	total := len(lines)
	if total > 0 && lines[total-1] == "" {
		total--
	}
	start := 1
	if o.Offset > 0 {
		start = o.Offset
	}
	if start > total {
		return nil, fail("invalid_argument", "offset %d is past the end (%d lines)", start, total)
	}
	end := total
	if o.Limit > 0 && start+o.Limit-1 < end {
		end = start + o.Limit - 1
	}
	body := strings.Join(lines[start-1:end], "\n")
	if o.MaxChars > 0 && len(body) > o.MaxChars {
		body = body[:o.MaxChars]
	}

	return &ReadResult{
		Path:       path,
		Text:       body,
		Encoding:   name,
		BOM:        info.BOM,
		EOL:        eol,
		Hash:       HashText(text),
		StartLine:  start,
		EndLine:    end,
		TotalLines: total,
		Bytes:      len(raw),
		Confidence: info.Confidence,
	}, nil
}

// WriteOptions describes a full-file write.
type WriteOptions struct {
	Content      string
	Encoding     string
	BOM          *bool
	EOL          string
	ExpectedHash string
	DryRun       bool
}

// WriteResult mirrors the tool output of write_file.
type WriteResult struct {
	Path     string `json:"path"`
	Bytes    int    `json:"bytes"`
	Encoding string `json:"encoding"`
	BOM      bool   `json:"bom"`
	EOL      string `json:"eol"`
	Hash     string `json:"hash"`
	Created  bool   `json:"created"`
	DryRun   bool   `json:"dryRun,omitempty"`
}

// Write stores content in the requested (or inherited) encoding.
func Write(path string, o WriteOptions) (*WriteResult, error) {
	name := "utf-8"
	bom := false
	eol := "lf"
	created := true

	if st, err := os.Stat(path); err == nil {
		if st.IsDir() {
			return nil, fail("is_directory", "%s is a directory", path)
		}
		created = false
		cur, err := Read(path, ReadOptions{})
		if err != nil {
			return nil, err
		}
		name, bom, eol = cur.Encoding, cur.BOM, cur.EOL
		if o.ExpectedHash != "" && o.ExpectedHash != cur.Hash {
			return nil, fail("hash_mismatch", "%s changed since it was read", path)
		}
	} else if !os.IsNotExist(err) {
		return nil, describe(err, path)
	}

	if o.Encoding != "" {
		if !enc.Valid(o.Encoding) {
			return nil, fail("encoding_unknown", "unsupported encoding %q", o.Encoding)
		}
		name = o.Encoding
	}
	if o.BOM != nil {
		bom = *o.BOM
	}
	if o.EOL != "" {
		e := strings.ToLower(o.EOL)
		if e != "lf" && e != "crlf" {
			return nil, fail("invalid_argument", "eol must be lf or crlf")
		}
		eol = e
	}

	text := strings.ReplaceAll(o.Content, "\r\n", "\n")
	text = strings.ReplaceAll(text, "\r", "\n")
	stored := text
	if eol == "crlf" {
		stored = strings.ReplaceAll(text, "\n", "\r\n")
	}
	raw, err := enc.Encode(stored, name, bom)
	if err != nil {
		return nil, fail("encoding_unknown", "cannot encode as %s: %v", name, err)
	}

	res := &WriteResult{
		Path: path, Bytes: len(raw), Encoding: name, BOM: bom,
		EOL: eol, Hash: HashText(text), Created: created, DryRun: o.DryRun,
	}
	if o.DryRun {
		return res, nil
	}
	if err := os.MkdirAll(filepath.Dir(path), 0o755); err != nil {
		return nil, describe(err, path)
	}
	if err := os.WriteFile(path, raw, 0o644); err != nil {
		return nil, describe(err, path)
	}
	return res, nil
}

// Edit is a single textual replacement.
type Edit struct {
	OldText    string `json:"oldText"`
	NewText    string `json:"newText"`
	ReplaceAll bool   `json:"replaceAll,omitempty"`
}

// EditOptions describes an in-place edit.
type EditOptions struct {
	Edits        []Edit
	Encoding     string
	ExpectedHash string
	DryRun       bool
}

// EditResult mirrors the tool output of edit_file.
type EditResult struct {
	Path    string `json:"path"`
	Changed int    `json:"changed"`
	Hash    string `json:"hash"`
	Diff    string `json:"diff,omitempty"`
	DryRun  bool   `json:"dryRun,omitempty"`
}

// Apply performs the replacements and rewrites the file in its own encoding.
func Apply(path string, o EditOptions) (*EditResult, error) {
	cur, err := Read(path, ReadOptions{Encoding: o.Encoding})
	if err != nil {
		return nil, err
	}
	if o.ExpectedHash != "" && o.ExpectedHash != cur.Hash {
		return nil, fail("hash_mismatch", "%s changed since it was read", path)
	}
	before := cur.Text
	after := before
	total := 0
	for i, e := range o.Edits {
		if e.OldText == "" {
			return nil, fail("invalid_argument", "edits[%d].oldText is empty", i)
		}
		n := strings.Count(after, e.OldText)
		if n == 0 {
			return nil, fail("invalid_argument", "edits[%d].oldText not found", i)
		}
		if n > 1 && !e.ReplaceAll {
			return nil, fail("invalid_argument", "edits[%d].oldText matches %d places; add more context or set replaceAll", i, n)
		}
		after = strings.ReplaceAll(after, e.OldText, e.NewText)
		total += n
	}

	res := &EditResult{Path: path, Changed: total, Hash: HashText(after), DryRun: o.DryRun}
	if total == 0 {
		return res, nil
	}
	res.Diff = lineDiff(before, after)
	if o.DryRun {
		return res, nil
	}
	_, err = Write(path, WriteOptions{Content: after, Encoding: cur.Encoding})
	if err != nil {
		return nil, err
	}
	return res, nil
}

// HashText returns a short stable fingerprint of normalised text.
func HashText(s string) string {
	sum := sha256.Sum256([]byte(s))
	return hex.EncodeToString(sum[:8])
}

// DetectEOL reports the dominant line ending as lf or crlf.
func DetectEOL(s string) string {
	crlf := strings.Count(s, "\r\n")
	lf := strings.Count(s, "\n") - crlf
	if crlf > lf {
		return "crlf"
	}
	return "lf"
}

// lineDiff renders the changed region of two texts as a unified hunk.
func lineDiff(before, after string) string {
	b := strings.Split(before, "\n")
	a := strings.Split(after, "\n")
	pre := 0
	for pre < len(a) && pre < len(b) && a[pre] == b[pre] {
		pre++
	}
	suf := 0
	for suf < len(a)-pre && suf < len(b)-pre && a[len(a)-1-suf] == b[len(b)-1-suf] {
		suf++
	}
	var sb strings.Builder
	for _, l := range b[pre : len(b)-suf] {
		sb.WriteString("- " + l + "\n")
	}
	for _, l := range a[pre : len(a)-suf] {
		sb.WriteString("+ " + l + "\n")
	}
	return strings.TrimRight(sb.String(), "\n")
}

func describe(err error, path string) error {
	if os.IsNotExist(err) {
		return fail("not_found", "%s does not exist", path)
	}
	return fail("io_error", "%v", err)
}
