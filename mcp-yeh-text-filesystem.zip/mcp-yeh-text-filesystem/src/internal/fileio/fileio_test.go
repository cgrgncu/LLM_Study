package fileio

import (
	"os"
	"path/filepath"
	"testing"
)

func TestWriteReadPreservesEncoding(t *testing.T) {
	dir := t.TempDir()
	p := filepath.Join(dir, "big5.txt")
	if _, err := Write(p, WriteOptions{Content: "第一行\n第二行\n", Encoding: "big5"}); err != nil {
		t.Fatal(err)
	}
	r, err := Read(p, ReadOptions{})
	if err != nil {
		t.Fatal(err)
	}
	if r.Encoding != "big5" || r.Text != "第一行\n第二行" || r.TotalLines != 2 {
		t.Fatalf("unexpected read: %+v", r)
	}
	raw, _ := os.ReadFile(p)
	if len(raw) >= len(r.Text) {
		t.Fatalf("expected big5 to be smaller than utf-8: %d vs %d", len(raw), len(r.Text))
	}
}

func TestEditKeepsEncodingAndRejectsStaleHash(t *testing.T) {
	dir := t.TempDir()
	p := filepath.Join(dir, "cp1251.txt")
	Write(p, WriteOptions{Content: "Привет\nмир\n", Encoding: "windows-1251"})
	r, _ := Read(p, ReadOptions{})

	res, err := Apply(p, EditOptions{ExpectedHash: r.Hash, Edits: []Edit{{OldText: "мир", NewText: "свет"}}})
	if err != nil {
		t.Fatal(err)
	}
	if res.Changed != 1 || res.Diff == "" {
		t.Fatalf("bad edit result: %+v", res)
	}
	after, _ := Read(p, ReadOptions{})
	if after.Encoding != "windows-1251" || after.Text != "Привет\nсвет" {
		t.Fatalf("edit lost encoding: %+v", after)
	}
	if _, err := Apply(p, EditOptions{ExpectedHash: r.Hash, Edits: []Edit{{OldText: "свет", NewText: "x"}}}); err == nil {
		t.Fatal("stale hash accepted")
	}
}

func TestWriteKeepsEOLAndBOM(t *testing.T) {
	dir := t.TempDir()
	p := filepath.Join(dir, "crlf.txt")
	bom := true
	if _, err := Write(p, WriteOptions{Content: "a\nb\n", EOL: "crlf", BOM: &bom}); err != nil {
		t.Fatal(err)
	}
	r, _ := Read(p, ReadOptions{})
	if r.EOL != "crlf" || !r.BOM || r.Text != "a\nb" {
		t.Fatalf("bad state: %+v", r)
	}
	if _, err := Write(p, WriteOptions{Content: "c\n"}); err != nil {
		t.Fatal(err)
	}
	raw, _ := os.ReadFile(p)
	if raw[0] != 0xEF || raw[len(raw)-1] != '\n' || raw[len(raw)-2] != '\r' {
		t.Fatalf("style not inherited: % x", raw)
	}
}

func TestDryRunDoesNotWrite(t *testing.T) {
	dir := t.TempDir()
	p := filepath.Join(dir, "x.txt")
	os.WriteFile(p, []byte("keep"), 0o644)
	if _, err := Write(p, WriteOptions{Content: "change", DryRun: true}); err != nil {
		t.Fatal(err)
	}
	raw, _ := os.ReadFile(p)
	if string(raw) != "keep" {
		t.Fatalf("dry run wrote: %q", raw)
	}
}

func TestReadRange(t *testing.T) {
	dir := t.TempDir()
	p := filepath.Join(dir, "lines.txt")
	Write(p, WriteOptions{Content: "1\n2\n3\n4\n5\n"})
	r, err := Read(p, ReadOptions{Offset: 2, Limit: 2})
	if err != nil {
		t.Fatal(err)
	}
	if r.Text != "2\n3" || r.StartLine != 2 || r.EndLine != 3 || r.TotalLines != 5 {
		t.Fatalf("bad range: %+v", r)
	}
}
