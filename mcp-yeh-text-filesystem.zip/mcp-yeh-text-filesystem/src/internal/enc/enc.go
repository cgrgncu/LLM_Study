// Package enc detects and converts text encodings.
package enc

import (
	"bytes"
	"errors"
	"strings"
	"unicode/utf8"

	"github.com/wlynxg/chardet"
	"golang.org/x/text/encoding"
	"golang.org/x/text/encoding/htmlindex"
	"golang.org/x/text/encoding/unicode"
	"golang.org/x/text/transform"
)

// Info describes the encoding of a byte slice.
type Info struct {
	Name       string `json:"name"`
	BOM        bool   `json:"bom"`
	Confidence int    `json:"confidence"`
}

// ErrUnknown is returned when a label cannot be resolved to a codec.
var ErrUnknown = errors.New("unknown encoding")

var utf8BOM = []byte{0xEF, 0xBB, 0xBF}

// Detect inspects raw bytes and reports the most likely encoding.
func Detect(b []byte) Info {
	switch {
	case bytes.HasPrefix(b, utf8BOM):
		return Info{Name: "utf-8", BOM: true, Confidence: 100}
	case bytes.HasPrefix(b, []byte{0xFF, 0xFE}):
		return Info{Name: "utf-16le", BOM: true, Confidence: 100}
	case bytes.HasPrefix(b, []byte{0xFE, 0xFF}):
		return Info{Name: "utf-16be", BOM: true, Confidence: 100}
	}
	if utf8.Valid(b) {
		return Info{Name: "utf-8", Confidence: 100}
	}
	if r := chardet.Detect(b); r.Charset != "" {
		name := canonical(r.Charset)
		if Valid(name) {
			return Info{Name: name, Confidence: int(r.Confidence * 100)}
		}
		return Info{Name: strings.ToLower(r.Charset), Confidence: int(r.Confidence * 100)}
	}
	return Info{Name: "unknown"}
}

// Decode converts b (in encoding name) to UTF-8 text. A BOM, if present, is
// removed from the result.
func Decode(b []byte, name string) (string, error) {
	name = canonical(name)
	switch {
	case name == "utf-8":
		return string(bytes.TrimPrefix(b, utf8BOM)), nil
	case name == "utf-16le" || name == "utf-16be":
		b = trimUTF16BOM(b)
		order := unicode.LittleEndian
		if name == "utf-16be" {
			order = unicode.BigEndian
		}
		dec := unicode.UTF16(order, unicode.IgnoreBOM).NewDecoder()
		out, _, err := transform.Bytes(dec, b)
		return string(out), err
	}
	codec, err := lookup(name)
	if err != nil {
		return "", err
	}
	out, _, err := transform.Bytes(codec.NewDecoder(), b)
	return string(out), err
}

// Encode converts UTF-8 text to the named encoding, optionally prefixing a BOM.
func Encode(s, name string, bom bool) ([]byte, error) {
	name = canonical(name)
	switch {
	case name == "utf-8":
		out := []byte(s)
		if bom {
			out = append(append([]byte{}, utf8BOM...), out...)
		}
		return out, nil
	case name == "utf-16le" || name == "utf-16be":
		order := unicode.LittleEndian
		mark := []byte{0xFF, 0xFE}
		if name == "utf-16be" {
			order = unicode.BigEndian
			mark = []byte{0xFE, 0xFF}
		}
		enc := unicode.UTF16(order, unicode.IgnoreBOM)
		out, _, err := transform.Bytes(enc.NewEncoder(), []byte(s))
		if err != nil {
			return nil, err
		}
		if bom {
			out = append(append([]byte{}, mark...), out...)
		}
		return out, nil
	}
	codec, err := lookup(name)
	if err != nil {
		return nil, err
	}
	out, _, err := transform.Bytes(codec.NewEncoder(), []byte(s))
	return out, err
}

// Valid reports whether name resolves to a supported codec.
func Valid(name string) bool {
	name = canonical(name)
	if name == "utf-8" || name == "utf-16le" || name == "utf-16be" {
		return true
	}
	_, err := lookup(name)
	return err == nil
}

// List returns the encoding labels this package can decode and encode.
func List() []string {
	return []string{
		"utf-8", "utf-16le", "utf-16be",
		"big5", "gbk", "gb18030", "hz-gb-2312",
		"shift_jis", "euc-jp", "iso-2022-jp",
		"euc-kr", "iso-2022-kr",
		"iso-8859-1", "iso-8859-2", "iso-8859-5", "iso-8859-15",
		"windows-1250", "windows-1251", "windows-1252", "windows-1253",
		"windows-1254", "windows-1255", "windows-1256", "windows-1257",
		"windows-1258", "windows-874",
		"koi8-r", "koi8-u", "macintosh", "ibm866",
	}
}

func lookup(name string) (encoding.Encoding, error) {
	if name == "" {
		return nil, ErrUnknown
	}
	e, err := htmlindex.Get(name)
	if err != nil || e == nil {
		return nil, ErrUnknown
	}
	return e, nil
}

// canonical normalises aliases to the labels listed by List.
func canonical(name string) string {
	n := strings.ToLower(strings.TrimSpace(name))
	n = strings.ReplaceAll(n, "_", "-")
	switch n {
	case "utf8", "utf-8-bom":
		return "utf-8"
	case "utf16", "utf-16", "utf-16-le":
		return "utf-16le"
	case "utf-16-be":
		return "utf-16be"
	case "cp950", "big5-hkscs", "x-big5", "big-5":
		return "big5"
	case "cp936", "x-gbk":
		return "gbk"
	case "gb-18030", "gb2312", "euc-cn":
		return "gb18030"
	case "sjis", "cp932", "windows-31j":
		return "shift_jis"
	case "eucjp":
		return "euc-jp"
	case "euckr", "cp949", "uhc":
		return "euc-kr"
	case "cp1250", "x-cp1250":
		return "windows-1250"
	case "cp1251", "x-cp1251":
		return "windows-1251"
	case "cp1252", "x-cp1252", "latin1", "latin-1":
		return "windows-1252"
	case "cp874":
		return "windows-874"
	case "koi8r":
		return "koi8-r"
	case "koi8u":
		return "koi8-u"
	case "mac", "mac-roman":
		return "macintosh"
	case "cp866":
		return "ibm866"
	}
	return n
}

func trimUTF16BOM(b []byte) []byte {
	if bytes.HasPrefix(b, []byte{0xFF, 0xFE}) || bytes.HasPrefix(b, []byte{0xFE, 0xFF}) {
		return b[2:]
	}
	return b
}
