package enc

import (
	"strings"
	"testing"
)

func TestRoundTrip(t *testing.T) {
	cases := []struct{ name, text string }{
		{"big5", "繁體中文測試，第一行。"},
		{"gb18030", "简体中文测试"},
		{"shift_jis", "日本語のテスト"},
		{"euc-kr", "한국어 테스트"},
		{"windows-1251", "Привет мир"},
		{"windows-1252", "Grüße"},
		{"utf-8", "héllo 世界"},
		{"utf-16le", "hello 世界"},
		{"utf-16be", "hello 世界"},
	}
	for _, c := range cases {
		raw, err := Encode(c.text, c.name, false)
		if err != nil {
			t.Fatalf("%s: encode: %v", c.name, err)
		}
		got, err := Decode(raw, c.name)
		if err != nil {
			t.Fatalf("%s: decode: %v", c.name, err)
		}
		if got != c.text {
			t.Fatalf("%s: got %q want %q", c.name, got, c.text)
		}
	}
}

func TestBOM(t *testing.T) {
	raw, err := Encode("abc", "utf-8", true)
	if err != nil {
		t.Fatal(err)
	}
	if len(raw) != 6 || raw[0] != 0xEF {
		t.Fatalf("missing utf-8 bom: % x", raw)
	}
	info := Detect(raw)
	if !info.BOM || info.Name != "utf-8" {
		t.Fatalf("detect bom: %+v", info)
	}
	got, err := Decode(raw, "utf-8")
	if err != nil || got != "abc" {
		t.Fatalf("bom not stripped: %q %v", got, err)
	}

	u16, err := Encode("hi", "utf-16le", true)
	if err != nil {
		t.Fatal(err)
	}
	if len(u16) != 6 || u16[0] != 0xFF || u16[1] != 0xFE {
		t.Fatalf("bad utf-16 bom: % x", u16)
	}
	if info := Detect(u16); info.Name != "utf-16le" || !info.BOM {
		t.Fatalf("utf-16 detect: %+v", info)
	}
}

func TestDetect(t *testing.T) {
	big5, _ := Encode("繁體中文測試內容，這是一段比較長的文字用來提高偵測信心。", "big5", false)
	if got := Detect(big5); got.Name != "big5" {
		t.Fatalf("big5 detect: %+v", got)
	}
	utf8 := []byte("plain ascii and 中文")
	if got := Detect(utf8); got.Name != "utf-8" || got.BOM {
		t.Fatalf("utf-8 detect: %+v", got)
	}
}

func TestAliases(t *testing.T) {
	for in, want := range map[string]string{
		"CP950": "big5", "cp936": "gbk", "utf8": "utf-8", "latin1": "windows-1252",
		"SJIS": "shift_jis", "GB2312": "gb18030", "UTF-16": "utf-16le",
	} {
		if got := canonical(in); got != want {
			t.Fatalf("%s -> %s, want %s", in, got, want)
		}
		if !Valid(in) {
			t.Fatalf("%s should be valid", in)
		}
	}
	if Valid("no-such-encoding") {
		t.Fatal("bogus encoding accepted")
	}
}

func TestListIsValid(t *testing.T) {
	for _, name := range List() {
		if !Valid(name) {
			t.Fatalf("listed encoding unusable: %s", name)
		}
		if strings.TrimSpace(name) != name {
			t.Fatalf("bad label %q", name)
		}
	}
}
