package tools

import (
	"bytes"
	"fmt"
	"io"
	"os"
	"strings"

	"mcp-yeh-text-filesystem/internal/enc"
	"mcp-yeh-text-filesystem/internal/fileio"
)

func (s *Server) readFile(in readIn) (any, error) {
	p, err := s.resolve(in.Path)
	if err != nil {
		return nil, wrap(err)
	}
	r, err := fileio.Read(p, fileio.ReadOptions{
		Offset: in.Offset, Limit: in.Limit, MaxChars: in.MaxChars, Encoding: in.Encoding,
	})
	if err != nil {
		return nil, wrap(err)
	}
	return r, nil
}

func (s *Server) readFiles(in readManyIn) (any, error) {
	type item struct {
		Path     string  `json:"path"`
		Text     string  `json:"text,omitempty"`
		Encoding string  `json:"encoding,omitempty"`
		Hash     string  `json:"hash,omitempty"`
		Lines    int     `json:"lines,omitempty"`
		Error    string  `json:"error,omitempty"`
	}
	out := make([]item, 0, len(in.Paths))
	for _, raw := range in.Paths {
		p, err := s.resolve(raw)
		if err != nil {
			out = append(out, item{Path: raw, Error: err.Error()})
			continue
		}
		r, err := fileio.Read(p, fileio.ReadOptions{MaxChars: in.MaxChars})
		if err != nil {
			out = append(out, item{Path: raw, Error: err.Error()})
			continue
		}
		out = append(out, item{Path: p, Text: r.Text, Encoding: r.Encoding, Hash: r.Hash, Lines: r.TotalLines})
	}
	return out, nil
}

func (s *Server) writeFile(in writeIn) (any, error) {
	p, err := s.resolve(in.Path)
	if err != nil {
		return nil, wrap(err)
	}
	r, err := fileio.Write(p, fileio.WriteOptions{
		Content: in.Content, Encoding: in.Encoding, BOM: in.BOM, EOL: in.EOL,
		ExpectedHash: in.ExpectedHash, DryRun: in.DryRun,
	})
	if err != nil {
		return nil, wrap(err)
	}
	return r, nil
}

func (s *Server) editFile(in editIn) (any, error) {
	p, err := s.resolve(in.Path)
	if err != nil {
		return nil, wrap(err)
	}
	r, err := fileio.Apply(p, fileio.EditOptions{
		Edits: in.Edits, Encoding: in.Encoding, ExpectedHash: in.ExpectedHash, DryRun: in.DryRun,
	})
	if err != nil {
		return nil, wrap(err)
	}
	return r, nil
}

func (s *Server) inspectEncoding(in statIn) (any, error) {
	p, err := s.resolve(in.Path)
	if err != nil {
		return nil, wrap(err)
	}
	st, err := os.Stat(p)
	if err != nil {
		return nil, wrap(err)
	}
	if st.IsDir() {
		return nil, wrap(&fileio.Error{Kind: "is_directory", Msg: p + " is a directory"})
	}
	head, err := readHead(p, 256<<10)
	if err != nil {
		return nil, wrap(err)
	}
	info := enc.Detect(head)
	var eol string
	if full, err := fileio.Read(p, fileio.ReadOptions{MaxChars: 1 << 20}); err == nil {
		eol = full.EOL
	}
	return map[string]any{
		"path":       p,
		"encoding":   info.Name,
		"bom":        info.BOM,
		"confidence": info.Confidence,
		"bytes":      st.Size(),
		"eol":        eol,
	}, nil
}

func (s *Server) transcode(in transcodeIn) (any, error) {
	p, err := s.resolve(in.Path)
	if err != nil {
		return nil, wrap(err)
	}
	if !enc.Valid(in.To) {
		return nil, fmt.Errorf("encoding_unknown: cannot write %q", in.To)
	}
	from := in.From
	if from == "" {
		head, err := readHead(p, 256<<10)
		if err != nil {
			return nil, wrap(err)
		}
		from = enc.Detect(head).Name
	}
	r, err := fileio.Read(p, fileio.ReadOptions{Encoding: from})
	if err != nil {
		return nil, wrap(err)
	}
	if in.Backup && !in.DryRun {
		raw, err := os.ReadFile(p)
		if err != nil {
			return nil, wrap(err)
		}
		if err := os.WriteFile(p+".bak", raw, 0o644); err != nil {
			return nil, wrap(err)
		}
	}
	keepBOM := r.BOM && enc.Valid(in.To)
	bomPtr := &keepBOM
	res, err := fileio.Write(p, fileio.WriteOptions{
		Content: r.Text, Encoding: in.To, BOM: bomPtr, DryRun: in.DryRun,
	})
	if err != nil {
		return nil, wrap(err)
	}
	return map[string]any{
		"path":     p,
		"from":     from,
		"to":       in.To,
		"bytes":    res.Bytes,
		"bom":      res.BOM,
		"dryRun":   res.DryRun,
		"backup":   in.Backup && !in.DryRun,
	}, nil
}

func (s *Server) fixLineEndings(in eolIn) (any, error) {
	p, err := s.resolve(in.Path)
	if err != nil {
		return nil, wrap(err)
	}
	style := strings.ToLower(in.Style)
	if style != "lf" && style != "crlf" {
		return nil, fmt.Errorf("invalid_argument: style must be lf or crlf")
	}
	r, err := fileio.Read(p, fileio.ReadOptions{})
	if err != nil {
		return nil, wrap(err)
	}
	if r.EOL == style && !in.DryRun {
		return map[string]any{"path": p, "eol": style, "changed": 0}, nil
	}
	res, err := fileio.Write(p, fileio.WriteOptions{Content: r.Text, EOL: style, DryRun: in.DryRun})
	if err != nil {
		return nil, wrap(err)
	}
	return map[string]any{"path": p, "eol": style, "bytes": res.Bytes, "dryRun": res.DryRun}, nil
}

func (s *Server) fixBOM(in bomIn) (any, error) {
	p, err := s.resolve(in.Path)
	if err != nil {
		return nil, wrap(err)
	}
	r, err := fileio.Read(p, fileio.ReadOptions{})
	if err != nil {
		return nil, wrap(err)
	}
	switch strings.ToLower(in.Action) {
	case "detect", "":
		return map[string]any{"path": p, "encoding": r.Encoding, "bom": r.BOM}, nil
	case "add", "remove":
		want := in.Action == "add"
		if r.BOM == want && !in.DryRun {
			return map[string]any{"path": p, "encoding": r.Encoding, "bom": want, "changed": 0}, nil
		}
		res, err := fileio.Write(p, fileio.WriteOptions{Content: r.Text, BOM: &want, DryRun: in.DryRun})
		if err != nil {
			return nil, wrap(err)
		}
		return map[string]any{"path": p, "encoding": res.Encoding, "bom": res.BOM, "bytes": res.Bytes, "dryRun": res.DryRun}, nil
	}
	return nil, fmt.Errorf("invalid_argument: action must be add, remove or detect")
}

func (s *Server) fileStat(in statIn) (any, error) {
	p, err := s.resolve(in.Path)
	if err != nil {
		return nil, wrap(err)
	}
	st, err := os.Stat(p)
	if err != nil {
		return nil, wrap(err)
	}
	out := map[string]any{
		"path":    p,
		"name":    st.Name(),
		"dir":     st.IsDir(),
		"size":    st.Size(),
		"mode":    st.Mode().String(),
		"modTime": st.ModTime().Format("2006-01-02T15:04:05Z07:00"),
	}
	if !st.IsDir() {
		head, err := readHead(p, 256<<10)
		if err == nil {
			info := enc.Detect(head)
			out["encoding"] = info.Name
			out["bom"] = info.BOM
			out["confidence"] = info.Confidence
		}
		if r, err := fileio.Read(p, fileio.ReadOptions{MaxChars: 1 << 20}); err == nil {
			out["eol"] = r.EOL
			out["lines"] = r.TotalLines
		}
	}
	return out, nil
}

func (s *Server) listRoots() (any, error) {
	return map[string]any{"roots": s.g.Roots()}, nil
}

func (s *Server) supportedEncodings() (any, error) {
	return map[string]any{"encodings": enc.List()}, nil
}

func readHead(p string, n int64) ([]byte, error) {
	f, err := os.Open(p)
	if err != nil {
		return nil, err
	}
	defer f.Close()
	var buf bytes.Buffer
	if _, err := io.CopyN(&buf, f, n); err != nil && err != io.EOF {
		return nil, err
	}
	return buf.Bytes(), nil
}
