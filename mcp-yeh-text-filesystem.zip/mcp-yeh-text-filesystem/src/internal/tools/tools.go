// Package tools registers the MCP tools exposed by mcp-yeh-text-filesystem.
package tools

import (
	"context"
	"errors"
	"fmt"
	"os"
	"path/filepath"
	"strings"

	"github.com/google/jsonschema-go/jsonschema"
	"github.com/modelcontextprotocol/go-sdk/mcp"

	"mcp-yeh-text-filesystem/internal/fileio"
	"mcp-yeh-text-filesystem/internal/guard"
)

// Server binds the tools to a guard and a version string.
type Server struct {
	g       *guard.Guard
	version string
}

var noArgs = &jsonschema.Schema{Type: "object", Properties: map[string]*jsonschema.Schema{}}

// Register builds the MCP server with every tool wired up.
func Register(g *guard.Guard, version string) *mcp.Server {
	s := &Server{g: g, version: version}
	srv := mcp.NewServer(&mcp.Implementation{
		Name:    "mcp-yeh-text-filesystem",
		Title:   "mcp-yeh-text-filesystem",
		Version: version,
	}, &mcp.ServerOptions{
		Instructions: "Encoding-aware text file server. Reads decode any supported encoding to UTF-8; writes restore the original encoding, BOM and line endings.",
	})

	add(srv, "read_file", "Read a text file. Encoding is detected automatically; content is returned as UTF-8. Returns encoding, bom, eol, hash, line range and total lines. Use offset/limit to page large files, and pass hash back as expectedHash when editing.",
		func(ctx context.Context, req *mcp.CallToolRequest, in readIn) (any, error) { return s.readFile(in) })

	add(srv, "read_files", "Read several text files in one call. Each entry reports its own encoding or an error; one failure does not stop the others.",
		func(ctx context.Context, req *mcp.CallToolRequest, in readManyIn) (any, error) { return s.readFiles(in) })

	add(srv, "write_file", "Create or fully overwrite a text file. Existing files keep their encoding, BOM and line ending style unless overridden. Pass expectedHash to fail instead of overwriting a changed file.",
		func(ctx context.Context, req *mcp.CallToolRequest, in writeIn) (any, error) { return s.writeFile(in) })

	add(srv, "edit_file", "Replace text inside a file. Each edit needs a unique oldText unless replaceAll is set. Returns a diff of the changed region; dryRun previews without writing.",
		func(ctx context.Context, req *mcp.CallToolRequest, in editIn) (any, error) { return s.editFile(in) })

	add(srv, "list_dir", "List directory entries with size and modification time. Filter by glob pattern, sort by name, mtime or size.",
		func(ctx context.Context, req *mcp.CallToolRequest, in listIn) (any, error) { return s.listDir(in) })

	add(srv, "tree_view", "Show a directory tree with depth and file count limits.",
		func(ctx context.Context, req *mcp.CallToolRequest, in treeIn) (any, error) { return s.treeView(in) })

	add(srv, "find_files", "Find files by name using a glob pattern, recursively.",
		func(ctx context.Context, req *mcp.CallToolRequest, in findIn) (any, error) { return s.findFiles(in) })

	add(srv, "search_content", "Search file contents by regular expression, recursively. Reports file, line number and matching line.",
		func(ctx context.Context, req *mcp.CallToolRequest, in searchIn) (any, error) { return s.searchContent(in) })

	add(srv, "inspect_encoding", "Report the detected encoding of a file without returning its content.",
		func(ctx context.Context, req *mcp.CallToolRequest, in statIn) (any, error) { return s.inspectEncoding(in) })

	add(srv, "transcode", "Convert a whole file from one encoding to another. When from is empty the source encoding is detected. backup keeps a copy beside the original.",
		func(ctx context.Context, req *mcp.CallToolRequest, in transcodeIn) (any, error) { return s.transcode(in) })

	add(srv, "fix_line_endings", "Normalise every line ending in a file to lf or crlf, keeping the encoding.",
		func(ctx context.Context, req *mcp.CallToolRequest, in eolIn) (any, error) { return s.fixLineEndings(in) })

	add(srv, "fix_bom", "Add, remove or inspect the byte order mark of a file.",
		func(ctx context.Context, req *mcp.CallToolRequest, in bomIn) (any, error) { return s.fixBOM(in) })

	add(srv, "file_stat", "Report size, timestamps, permissions, encoding, BOM and line ending style of a file.",
		func(ctx context.Context, req *mcp.CallToolRequest, in statIn) (any, error) { return s.fileStat(in) })

	add(srv, "copy_path", "Copy a file or directory tree to a new location inside the allowed roots.",
		func(ctx context.Context, req *mcp.CallToolRequest, in moveIn) (any, error) { return s.copyPath(in) })

	add(srv, "move_path", "Move or rename a file or directory inside the allowed roots.",
		func(ctx context.Context, req *mcp.CallToolRequest, in moveIn) (any, error) { return s.movePath(in) })

	add(srv, "delete_path", "Delete a file, or an empty directory. Directories are never removed recursively.",
		func(ctx context.Context, req *mcp.CallToolRequest, in statIn) (any, error) { return s.deletePath(in) })

	add(srv, "make_dir", "Create a directory and any missing parents.",
		func(ctx context.Context, req *mcp.CallToolRequest, in statIn) (any, error) { return s.makeDir(in) })

	addNoArgs(srv, "list_roots", "List the directories this server may access.", s.listRoots)
	addNoArgs(srv, "supported_encodings", "List every encoding this server can read and write.", s.supportedEncodings)

	return srv
}

func add[In any](srv *mcp.Server, name, desc string, h func(context.Context, *mcp.CallToolRequest, In) (any, error)) {
	mcp.AddTool(srv, &mcp.Tool{Name: name, Description: desc}, func(ctx context.Context, req *mcp.CallToolRequest, in In) (*mcp.CallToolResult, any, error) {
		out, err := h(ctx, req, in)
		if err != nil {
			return nil, nil, err
		}
		return nil, out, nil
	})
}

func addNoArgs(srv *mcp.Server, name, desc string, h func() (any, error)) {
	mcp.AddTool(srv, &mcp.Tool{Name: name, Description: desc, InputSchema: noArgs}, func(ctx context.Context, req *mcp.CallToolRequest, _ struct{}) (*mcp.CallToolResult, any, error) {
		out, err := h()
		if err != nil {
			return nil, nil, err
		}
		return nil, out, nil
	})
}

// ---- input types ----

type readIn struct {
	Path     string `json:"path"`
	Offset   int    `json:"offset,omitempty"`
	Limit    int    `json:"limit,omitempty"`
	MaxChars int    `json:"maxChars,omitempty"`
	Encoding string `json:"encoding,omitempty"`
}

type readManyIn struct {
	Paths    []string `json:"paths"`
	MaxChars int      `json:"maxChars,omitempty"`
}

type writeIn struct {
	Path         string `json:"path"`
	Content      string `json:"content"`
	Encoding     string `json:"encoding,omitempty"`
	BOM          *bool  `json:"bom,omitempty"`
	EOL          string `json:"eol,omitempty"`
	ExpectedHash string `json:"expectedHash,omitempty"`
	DryRun       bool   `json:"dryRun,omitempty"`
}

type editIn struct {
	Path         string        `json:"path"`
	Edits        []fileio.Edit `json:"edits"`
	Encoding     string        `json:"encoding,omitempty"`
	ExpectedHash string        `json:"expectedHash,omitempty"`
	DryRun       bool          `json:"dryRun,omitempty"`
}

type listIn struct {
	Path    string `json:"path"`
	Pattern string `json:"pattern,omitempty"`
	Sort    string `json:"sort,omitempty"`
	Reverse bool   `json:"reverse,omitempty"`
	Limit   int    `json:"limit,omitempty"`
}

type treeIn struct {
	Path     string `json:"path"`
	Depth    int    `json:"depth,omitempty"`
	MaxFiles int    `json:"maxFiles,omitempty"`
}

type findIn struct {
	Path       string `json:"path"`
	Pattern    string `json:"pattern"`
	MaxResults int    `json:"maxResults,omitempty"`
}

type searchIn struct {
	Path          string `json:"path"`
	Pattern       string `json:"pattern"`
	CaseSensitive bool   `json:"caseSensitive,omitempty"`
	Include       string `json:"include,omitempty"`
	MaxMatches    int    `json:"maxMatches,omitempty"`
	ContextBefore int    `json:"contextBefore,omitempty"`
	ContextAfter  int    `json:"contextAfter,omitempty"`
}

type statIn struct {
	Path string `json:"path"`
}

type transcodeIn struct {
	Path    string `json:"path"`
	From    string `json:"from,omitempty"`
	To      string `json:"to"`
	Backup  bool   `json:"backup,omitempty"`
	DryRun  bool   `json:"dryRun,omitempty"`
}

type eolIn struct {
	Path   string `json:"path"`
	Style  string `json:"style"`
	DryRun bool   `json:"dryRun,omitempty"`
}

type bomIn struct {
	Path   string `json:"path"`
	Action string `json:"action"`
	DryRun bool   `json:"dryRun,omitempty"`
}

type moveIn struct {
	From   string `json:"from"`
	To     string `json:"to"`
	DryRun bool   `json:"dryRun,omitempty"`
}

// ---- helpers ----

func (s *Server) resolve(p string) (string, error) {
	return s.g.Resolve(p)
}

func wrap(err error) error {
	var fe *fileio.Error
	if errors.As(err, &fe) {
		return fmt.Errorf("%s: %s", fe.Kind, fe.Msg)
	}
	var oe *guard.OutsideError
	if errors.As(err, &oe) {
		return fmt.Errorf("path_outside_roots: %s", oe.Error())
	}
	if os.IsNotExist(err) {
		return fmt.Errorf("not_found: %v", err)
	}
	return fmt.Errorf("io_error: %v", err)
}

func isDir(p string) bool {
	st, err := os.Stat(p)
	return err == nil && st.IsDir()
}

func base(p string) string { return filepath.Base(p) }

func cleanRel(p string) string {
	return strings.ReplaceAll(filepath.ToSlash(p), "\\", "/")
}
