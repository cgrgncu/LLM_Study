package tools

import (
	"fmt"
	"io"
	"os"
	"path/filepath"
	"regexp"
	"sort"
	"strings"

	"mcp-yeh-text-filesystem/internal/fileio"
)

type entry struct {
	Name    string `json:"name"`
	Dir     bool   `json:"dir,omitempty"`
	Size    int64  `json:"size,omitempty"`
	ModTime string `json:"modTime,omitempty"`
}

func (s *Server) listDir(in listIn) (any, error) {
	p, err := s.resolve(in.Path)
	if err != nil {
		return nil, wrap(err)
	}
	items, err := os.ReadDir(p)
	if err != nil {
		return nil, wrap(err)
	}
	out := make([]entry, 0, len(items))
	for _, it := range items {
		if in.Pattern != "" {
			ok, _ := filepath.Match(in.Pattern, it.Name())
			if !ok {
				continue
			}
		}
		e := entry{Name: it.Name(), Dir: it.IsDir()}
		if info, err := it.Info(); err == nil {
			e.Size = info.Size()
			e.ModTime = info.ModTime().Format("2006-01-02 15:04")
		}
		out = append(out, e)
	}
	switch in.Sort {
	case "mtime":
		sort.SliceStable(out, func(i, j int) bool { return out[i].ModTime > out[j].ModTime })
	case "size":
		sort.SliceStable(out, func(i, j int) bool { return out[i].Size > out[j].Size })
	default:
		sort.SliceStable(out, func(i, j int) bool {
			if out[i].Dir != out[j].Dir {
				return out[i].Dir
			}
			return strings.ToLower(out[i].Name) < strings.ToLower(out[j].Name)
		})
	}
	if in.Reverse {
		for i, j := 0, len(out)-1; i < j; i, j = i+1, j-1 {
			out[i], out[j] = out[j], out[i]
		}
	}
	total := len(out)
	if in.Limit > 0 && len(out) > in.Limit {
		out = out[:in.Limit]
	}
	return map[string]any{"path": p, "total": total, "entries": out}, nil
}

func (s *Server) treeView(in treeIn) (any, error) {
	p, err := s.resolve(in.Path)
	if err != nil {
		return nil, wrap(err)
	}
	depth := in.Depth
	if depth <= 0 {
		depth = 3
	}
	max := in.MaxFiles
	if max <= 0 {
		max = 500
	}
	root := p
	var sb strings.Builder
	files, dirs := 0, 0
	truncated := false

	err = filepath.WalkDir(p, func(path string, d os.DirEntry, walkErr error) error {
		if walkErr != nil {
			return nil
		}
		if path != root {
			rel, err := filepath.Rel(root, path)
			if err != nil {
				return nil
			}
			depthNow := len(strings.Split(cleanRel(rel), "/"))
			if d.IsDir() && depthNow >= depth {
				return filepath.SkipDir
			}
			if !d.IsDir() && depthNow > depth {
				return nil
			}
			indent := strings.Repeat("  ", depthNow-1)
			name := d.Name()
			if d.IsDir() {
				name += "/"
				dirs++
			} else {
				files++
			}
			if files+dirs > max {
				truncated = true
				return filepath.SkipAll
			}
			sb.WriteString(indent + name + "\n")
		}
		return nil
	})
	if err != nil {
		return nil, wrap(err)
	}
	return map[string]any{
		"path": root, "tree": strings.TrimRight(sb.String(), "\n"),
		"files": files, "dirs": dirs, "truncated": truncated,
	}, nil
}

func (s *Server) findFiles(in findIn) (any, error) {
	p, err := s.resolve(in.Path)
	if err != nil {
		return nil, wrap(err)
	}
	if in.Pattern == "" {
		return nil, fmt.Errorf("invalid_argument: pattern is required")
	}
	limit := in.MaxResults
	if limit <= 0 {
		limit = 500
	}
	var out []string
	truncated := false
	err = filepath.WalkDir(p, func(path string, d os.DirEntry, walkErr error) error {
		if walkErr != nil {
			return nil
		}
		if d.IsDir() {
			return nil
		}
		ok, _ := filepath.Match(in.Pattern, d.Name())
		if !ok {
			return nil
		}
		rel, err := filepath.Rel(p, path)
		if err != nil {
			return nil
		}
		out = append(out, cleanRel(rel))
		if len(out) >= limit {
			truncated = true
			return filepath.SkipAll
		}
		return nil
	})
	if err != nil {
		return nil, wrap(err)
	}
	return map[string]any{"path": p, "total": len(out), "truncated": truncated, "files": out}, nil
}

type match struct {
	File string `json:"file"`
	Line int    `json:"line"`
	Text string `json:"text"`
	Before []string `json:"before,omitempty"`
	After  []string `json:"after,omitempty"`
}

func (s *Server) searchContent(in searchIn) (any, error) {
	p, err := s.resolve(in.Path)
	if err != nil {
		return nil, wrap(err)
	}
	expr := in.Pattern
	if !in.CaseSensitive {
		expr = "(?i)" + expr
	}
	re, err := regexp.Compile(expr)
	if err != nil {
		return nil, fmt.Errorf("invalid_argument: %v", err)
	}
	limit := in.MaxMatches
	if limit <= 0 {
		limit = 200
	}
	var matches []match
	truncated := false

	err = filepath.WalkDir(p, func(path string, d os.DirEntry, walkErr error) error {
		if walkErr != nil {
			return nil
		}
		if d.IsDir() {
			return nil
		}
		if in.Include != "" {
			ok, _ := filepath.Match(in.Include, d.Name())
			if !ok {
				return nil
			}
		}
		head, err := readHead(path, 8<<10)
		if err != nil || strings.ContainsRune(string(head), 0) {
			return nil
		}
		r, err := fileio.Read(path, fileio.ReadOptions{})
		if err != nil {
			return nil
		}
		rel, err := filepath.Rel(p, path)
		if err != nil {
			rel = path
		}
		lines := strings.Split(r.Text, "\n")
		for i, line := range lines {
			if !re.MatchString(line) {
				continue
			}
			m := match{File: cleanRel(rel), Line: i + 1, Text: truncate(line, 400)}
			for j := maxInt(0, i-in.ContextBefore); j < i; j++ {
				m.Before = append(m.Before, truncate(lines[j], 400))
			}
			for j := i + 1; j <= minInt(len(lines)-1, i+in.ContextAfter); j++ {
				m.After = append(m.After, truncate(lines[j], 400))
			}
			matches = append(matches, m)
			if len(matches) >= limit {
				truncated = true
				return filepath.SkipAll
			}
		}
		return nil
	})
	if err != nil {
		return nil, wrap(err)
	}
	return map[string]any{"path": p, "total": len(matches), "truncated": truncated, "matches": matches}, nil
}

func (s *Server) copyPath(in moveIn) (any, error) {
	from, err := s.resolve(in.From)
	if err != nil {
		return nil, wrap(err)
	}
	to, err := s.resolve(in.To)
	if err != nil {
		return nil, wrap(err)
	}
	if _, err := os.Stat(to); err == nil {
		return nil, fmt.Errorf("invalid_argument: destination %s already exists", to)
	}
	st, err := os.Stat(from)
	if err != nil {
		return nil, wrap(err)
	}
	var files int
	if st.IsDir() {
		err = filepath.WalkDir(from, func(path string, d os.DirEntry, walkErr error) error {
			if walkErr != nil {
				return walkErr
			}
			rel, err := filepath.Rel(from, path)
			if err != nil {
				return err
			}
			target := filepath.Join(to, rel)
			if d.IsDir() {
				return os.MkdirAll(target, 0o755)
			}
			files++
			return copyFile(path, target)
		})
	} else {
		files = 1
		err = copyFile(from, to)
	}
	if err != nil {
		return nil, wrap(err)
	}
	return map[string]any{"from": from, "to": to, "files": files, "dryRun": in.DryRun}, nil
}

func (s *Server) movePath(in moveIn) (any, error) {
	from, err := s.resolve(in.From)
	if err != nil {
		return nil, wrap(err)
	}
	to, err := s.resolve(in.To)
	if err != nil {
		return nil, wrap(err)
	}
	if in.DryRun {
		return map[string]any{"from": from, "to": to, "dryRun": true}, nil
	}
	if _, err := os.Stat(to); err == nil {
		return nil, fmt.Errorf("invalid_argument: destination %s already exists", to)
	}
	if err := os.MkdirAll(filepath.Dir(to), 0o755); err != nil {
		return nil, wrap(err)
	}
	if err := os.Rename(from, to); err != nil {
		return nil, wrap(err)
	}
	return map[string]any{"from": from, "to": to, "dryRun": false}, nil
}

func (s *Server) deletePath(in statIn) (any, error) {
	p, err := s.resolve(in.Path)
	if err != nil {
		return nil, wrap(err)
	}
	st, err := os.Stat(p)
	if err != nil {
		return nil, wrap(err)
	}
	if err := os.Remove(p); err != nil {
		if st.IsDir() {
			return nil, fmt.Errorf("io_error: directory not empty; remove its files first")
		}
		return nil, wrap(err)
	}
	return map[string]any{"path": p, "dir": st.IsDir(), "deleted": true}, nil
}

func (s *Server) makeDir(in statIn) (any, error) {
	p, err := s.resolve(in.Path)
	if err != nil {
		return nil, wrap(err)
	}
	if err := os.MkdirAll(p, 0o755); err != nil {
		return nil, wrap(err)
	}
	return map[string]any{"path": p, "created": true}, nil
}

func copyFile(src, dst string) error {
	if err := os.MkdirAll(filepath.Dir(dst), 0o755); err != nil {
		return err
	}
	in, err := os.Open(src)
	if err != nil {
		return err
	}
	defer in.Close()
	st, err := in.Stat()
	if err != nil {
		return err
	}
	out, err := os.OpenFile(dst, os.O_WRONLY|os.O_CREATE|os.O_TRUNC, st.Mode().Perm())
	if err != nil {
		return err
	}
	if _, err := io.Copy(out, in); err != nil {
		out.Close()
		return err
	}
	return out.Close()
}

func truncate(s string, n int) string {
	if len(s) <= n {
		return s
	}
	return s[:n] + "..."
}

func minInt(a, b int) int {
	if a < b {
		return a
	}
	return b
}

func maxInt(a, b int) int {
	if a > b {
		return a
	}
	return b
}
