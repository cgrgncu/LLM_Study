// Package guard confines every filesystem operation to configured roots.
package guard

import (
	"fmt"
	"os"
	"path/filepath"
	"strings"
)

// Guard holds the resolved allow-list.
type Guard struct {
	roots []string
}

// OutsideError reports a path that fell out of the allow-list.
type OutsideError struct {
	Path  string
	Roots []string
}

func (e *OutsideError) Error() string {
	return fmt.Sprintf("path %q is outside the allowed roots", e.Path)
}

// New resolves each root to a real absolute path. Roots must already exist.
func New(roots []string) (*Guard, error) {
	var out []string
	seen := map[string]bool{}
	for _, r := range roots {
		r = strings.TrimSpace(r)
		if r == "" {
			continue
		}
		abs, err := filepath.Abs(r)
		if err != nil {
			return nil, err
		}
		real, err := filepath.EvalSymlinks(abs)
		if err != nil {
			return nil, fmt.Errorf("root %q: %w", r, err)
		}
		real = filepath.Clean(real)
		if !seen[strings.ToLower(real)] {
			seen[strings.ToLower(real)] = true
			out = append(out, real)
		}
	}
	if len(out) == 0 {
		return nil, fmt.Errorf("no allowed roots configured")
	}
	return &Guard{roots: out}, nil
}

// Roots returns the resolved allow-list.
func (g *Guard) Roots() []string {
	out := make([]string, len(g.roots))
	copy(out, g.roots)
	return out
}

// Resolve turns p into a real absolute path and verifies containment.
func (g *Guard) Resolve(p string) (string, error) {
	if strings.TrimSpace(p) == "" {
		return "", fmt.Errorf("empty path")
	}
	abs, err := filepath.Abs(p)
	if err != nil {
		return "", err
	}
	real, err := resolveExisting(abs)
	if err != nil {
		return "", err
	}
	lower := strings.ToLower(real)
	for _, root := range g.roots {
		if lower == strings.ToLower(root) {
			return real, nil
		}
		if strings.HasPrefix(lower, strings.ToLower(root)+string(os.PathSeparator)) {
			return real, nil
		}
	}
	return "", &OutsideError{Path: real, Roots: g.roots}
}

// resolveExisting evaluates symlinks on the longest existing prefix of p and
// re-appends the part that does not exist yet.
func resolveExisting(p string) (string, error) {
	p = filepath.Clean(p)
	var missing []string
	cur := p
	for {
		if _, err := os.Lstat(cur); err == nil {
			real, err := filepath.EvalSymlinks(cur)
			if err != nil {
				return "", err
			}
			for i := len(missing) - 1; i >= 0; i-- {
				real = filepath.Join(real, missing[i])
			}
			return filepath.Clean(real), nil
		}
		parent := filepath.Dir(cur)
		if parent == cur {
			return filepath.Clean(p), nil
		}
		missing = append(missing, filepath.Base(cur))
		cur = parent
	}
}
