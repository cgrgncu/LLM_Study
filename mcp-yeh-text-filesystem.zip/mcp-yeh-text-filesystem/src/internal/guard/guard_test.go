package guard

import (
	"os"
	"path/filepath"
	"strings"
	"testing"
)

func TestResolveInside(t *testing.T) {
	root := t.TempDir()
	g, err := New([]string{root})
	if err != nil {
		t.Fatal(err)
	}
	nested := filepath.Join(root, "a", "b", "new.txt")
	got, err := g.Resolve(nested)
	if err != nil {
		t.Fatalf("nested path rejected: %v", err)
	}
	if !strings.HasPrefix(strings.ToLower(got), strings.ToLower(root)) {
		t.Fatalf("resolved outside: %s", got)
	}
	if _, err := g.Resolve(root); err != nil {
		t.Fatalf("root itself rejected: %v", err)
	}
}

func TestResolveOutside(t *testing.T) {
	root := t.TempDir()
	g, err := New([]string{root})
	if err != nil {
		t.Fatal(err)
	}
	for _, p := range []string{
		filepath.Join(root, "..", "escape.txt"),
		filepath.Join(root, ".."),
		"./../../etc/passwd",
	} {
		if _, err := g.Resolve(p); err == nil {
			t.Fatalf("escaped with %q", p)
		}
	}
}

func TestRootMustExist(t *testing.T) {
	if _, err := New([]string{filepath.Join(t.TempDir(), "nope")}); err == nil {
		t.Fatal("missing root accepted")
	}
	if _, err := New(nil); err == nil {
		t.Fatal("empty root list accepted")
	}
}

func TestDuplicatesCollapse(t *testing.T) {
	root := t.TempDir()
	g, err := New([]string{root, root + string(os.PathSeparator) + ".", strings.ToUpper(root)})
	if err != nil {
		t.Fatal(err)
	}
	if len(g.Roots()) != 1 {
		t.Fatalf("expected 1 root, got %v", g.Roots())
	}
}
