@echo off
cd /d "%~dp0src"
set CGO_ENABLED=0
set GOFLAGS=-mod=vendor
set GOPROXY=off
if not exist "..\exe" mkdir "..\exe"
go build -trimpath -ldflags="-s -w" -o ..\exe\mcp-yeh-text-filesystem.exe
if errorlevel 1 (
    echo Build failed.
    exit /b 1
)
echo Build complete: ..\exe\mcp-yeh-text-filesystem.exe
