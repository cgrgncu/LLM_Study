// End-to-end probe for mcp-yeh-text-filesystem over MCP stdio.
import { spawn } from "node:child_process";
import { mkdirSync, rmSync, readFileSync, writeFileSync } from "node:fs";
import { fileURLToPath } from "node:url";
import path from "node:path";

const here = path.dirname(fileURLToPath(import.meta.url));
const exe = path.join(here, "..", "exe", "mcp-yeh-text-filesystem.exe");
const root = path.join(here, ".probe-root");

rmSync(root, { recursive: true, force: true });
mkdirSync(root, { recursive: true });
mkdirSync(path.join(root, "sub"), { recursive: true });
writeFileSync(path.join(root, "sub", "a.txt"), "alpha\nbeta\n");

const child = spawn(exe, [root], { stdio: ["pipe", "pipe", "pipe"] });
let stderr = "";
child.stderr.on("data", (d) => (stderr += d.toString()));

let id = 0;
const pending = new Map();
let buf = "";
child.stdout.on("data", (d) => {
  buf += d.toString("utf8");
  let i;
  while ((i = buf.indexOf("\n")) >= 0) {
    const line = buf.slice(0, i).trim();
    buf = buf.slice(i + 1);
    if (!line) continue;
    const msg = JSON.parse(line);
    if (msg.id !== undefined && pending.has(msg.id)) {
      pending.get(msg.id)(msg);
      pending.delete(msg.id);
    }
  }
});

const send = (method, params) =>
  new Promise((resolve) => {
    const mid = ++id;
    pending.set(mid, resolve);
    child.stdin.write(JSON.stringify({ jsonrpc: "2.0", id: mid, method, params }) + "\n");
  });
const notify = (method, params) =>
  child.stdin.write(JSON.stringify({ jsonrpc: "2.0", method, params }) + "\n");

const fail = [];
const ok = [];
function check(name, cond, detail) {
  if (cond) ok.push(name);
  else fail.push(`${name}${detail ? " -> " + JSON.stringify(detail) : ""}`);
}

async function call(name, args = {}) {
  const res = await send("tools/call", { name, arguments: args });
  if (res.error) return { error: res.error };
  const r = res.result ?? {};
  if (r.structuredContent) return { ...r.structuredContent, _isError: r.isError };
  const text = (r.content ?? []).map((c) => c.text ?? "").join("");
  if (r.isError) return { error: text };
  try {
    return JSON.parse(text);
  } catch {
    return { text };
  }
}

const init = await send("initialize", {
  protocolVersion: "2025-06-18",
  capabilities: {},
  clientInfo: { name: "probe", version: "1" },
});
check("initialize", init.result?.serverInfo?.name === "mcp-yeh-text-filesystem", init);

notify("notifications/initialized", {});

const list = await send("tools/list", {});
const tools = list.result?.tools ?? [];
check("tool count = 19", tools.length === 19, tools.map((t) => t.name));
const noArgs = tools.find((t) => t.name === "list_roots");
check(
  "no-arg schema has properties",
  noArgs?.inputSchema?.type === "object" && noArgs?.inputSchema?.properties !== undefined,
  noArgs?.inputSchema,
);

// --- write in Big5, read back ---
const w = await call("write_file", {
  path: path.join(root, "big5.txt"),
  content: "第一行\n第二行\n",
  encoding: "big5",
});
check("write big5", w.encoding === "big5" && !w.error, w);

const rawBig5 = readFileSync(path.join(root, "big5.txt"));
check("big5 bytes are not utf-8", !isUtf8(rawBig5), [...rawBig5]);

const r1 = await call("read_file", { path: path.join(root, "big5.txt") });
check(
  "read big5 decodes",
  r1.text === "第一行\n第二行" && r1.encoding === "big5" && r1.eol === "lf" && r1.totalLines === 2,
  r1,
);
check("read reports hash", typeof r1.hash === "string" && r1.hash.length === 16, r1.hash);

// --- edit keeps encoding ---
const e1 = await call("edit_file", {
  path: path.join(root, "big5.txt"),
  expectedHash: r1.hash,
  edits: [{ oldText: "第二行", newText: "第二行(改)" }],
});
check("edit changed 1", e1.changed === 1 && typeof e1.diff === "string", e1);
const r2 = await call("read_file", { path: path.join(root, "big5.txt") });
check("edit kept big5", r2.encoding === "big5" && r2.text.includes("第二行(改)"), r2);
check("edit reencoded as big5", !isUtf8(readFileSync(path.join(root, "big5.txt"))), null);

// --- stale hash rejected ---
const e2 = await call("edit_file", {
  path: path.join(root, "big5.txt"),
  expectedHash: r1.hash,
  edits: [{ oldText: "第一行", newText: "X" }],
});
check("stale hash rejected", /hash_mismatch/.test(e2.error ?? ""), e2);

// --- ambiguous edit rejected ---
const e3 = await call("edit_file", {
  path: path.join(root, "big5.txt"),
  edits: [{ oldText: "行", newText: "列" }],
});
check("ambiguous edit rejected", /matches 2 places/.test(e3.error ?? ""), e3);

// --- new file defaults ---
const w2 = await call("write_file", {
  path: path.join(root, "sub", "new.txt"),
  content: "a\nb\n",
  eol: "crlf",
});
check("new file utf-8 crlf", w2.encoding === "utf-8" && w2.eol === "crlf" && w2.created === true, w2);
check("crlf bytes", readFileSync(path.join(root, "sub", "new.txt")).includes(Buffer.from("\r\n")), null);
const r3 = await call("read_file", { path: path.join(root, "sub", "new.txt") });
check("crlf detected", r3.eol === "crlf" && r3.text === "a\nb", r3);

// --- encoding inspection + transcode ---
const enc1 = await call("inspect_encoding", { path: path.join(root, "big5.txt") });
check("inspect_encoding", enc1.encoding === "big5" && enc1.bom === false, enc1);

const t1 = await call("transcode", { path: path.join(root, "big5.txt"), to: "utf-8" });
check("transcode to utf-8", t1.to === "utf-8" && t1.from === "big5", t1);
const r4 = await call("read_file", { path: path.join(root, "big5.txt") });
check("transcoded text intact", r4.encoding === "utf-8" && r4.text.includes("第二行(改)"), r4);

// --- BOM ---
const b1 = await call("fix_bom", { path: path.join(root, "big5.txt"), action: "add" });
check("bom added", b1.bom === true, b1);
check("utf-8 bom bytes", readFileSync(path.join(root, "big5.txt")).subarray(0, 3).equals(Buffer.from([0xef, 0xbb, 0xbf])), null);
const r5 = await call("read_file", { path: path.join(root, "big5.txt") });
check("bom reported and stripped", r5.bom === true && !r5.text.startsWith("\uFEFF"), r5);
const b2 = await call("fix_bom", { path: path.join(root, "big5.txt"), action: "remove" });
check("bom removed", b2.bom === false, b2);

// --- UTF-16 round trip ---
const w3 = await call("write_file", {
  path: path.join(root, "u16.txt"),
  content: "hello 世界\n",
  encoding: "utf-16le",
  bom: true,
});
check("write utf-16", w3.encoding === "utf-16le" && w3.bom === true, w3);
const r6 = await call("read_file", { path: path.join(root, "u16.txt") });
check("read utf-16", r6.text === "hello 世界" && r6.bom === true, r6);

// --- windows-1251 ---
const w4 = await call("write_file", {
  path: path.join(root, "ru.txt"),
  content: "Привет мир\n",
  encoding: "windows-1251",
});
check("write cp1251", w4.encoding === "windows-1251", w4);
const r7 = await call("read_file", { path: path.join(root, "ru.txt") });
check("read cp1251", r7.text === "Привет мир" && r7.encoding === "windows-1251", r7);

// --- directory tools ---
const l1 = await call("list_dir", { path: root });
check("list_dir", (l1.entries ?? []).some((e) => e.name === "big5.txt"), l1);
const l2 = await call("list_dir", { path: root, pattern: "*.txt" });
check("list_dir pattern", (l2.entries ?? []).every((e) => e.name.endsWith(".txt")), l2);
const t2 = await call("tree_view", { path: root, depth: 2 });
check("tree_view", t2.tree.includes("sub/") && t2.files >= 1, t2);
const f1 = await call("find_files", { path: root, pattern: "*.txt" });
check("find_files", f1.files.includes("sub/a.txt"), f1);
const s1 = await call("search_content", { path: root, pattern: "beta" });
check("search_content", s1.matches?.[0]?.file === "sub/a.txt" && s1.matches[0].line === 2, s1);
const s2 = await call("search_content", { path: root, pattern: "ALPHA" });
check("search case-insensitive", s2.total === 1, s2);

const st = await call("file_stat", { path: path.join(root, "big5.txt") });
check("file_stat", st.dir === false && st.size > 0 && st.encoding === "utf-8", st);

// --- copy / move / mkdir / delete ---
const c1 = await call("copy_path", { from: path.join(root, "sub", "a.txt"), to: path.join(root, "a-copy.txt") });
check("copy file", c1.files === 1 && readFileSync(path.join(root, "a-copy.txt"), "utf8") === "alpha\nbeta\n", c1);
const c2 = await call("copy_path", { from: path.join(root, "sub"), to: path.join(root, "sub2") });
check("copy dir", c2.files === 2, c2);
const m1 = await call("move_path", { from: path.join(root, "a-copy.txt"), to: path.join(root, "moved.txt") });
check("move file", m1.to.endsWith("moved.txt"), m1);
const d1 = await call("delete_path", { path: path.join(root, "moved.txt") });
check("delete file", d1.deleted === true, d1);
const md1 = await call("make_dir", { path: path.join(root, "deep", "nested") });
check("make_dir", md1.created === true, md1);

// --- guards ---
const out = await call("read_file", { path: path.join(root, "..", "outside.txt") });
check("outside root rejected", /path_outside_roots/.test(out.error ?? ""), out);
const missing = await call("read_file", { path: path.join(root, "nope.txt") });
check("missing file", /not_found/.test(missing.error ?? ""), missing);
const dirRead = await call("read_file", { path: path.join(root, "sub") });
check("dir read rejected", /is_directory/.test(dirRead.error ?? ""), dirRead);
const noDir = await call("delete_path", { path: path.join(root, "sub2") });
check("non-empty dir delete rejected", /not empty/.test(noDir.error ?? ""), noDir);

const roots = await call("list_roots");
check("list_roots", roots.roots?.[0] === root, roots);
const encs = await call("supported_encodings");
check("supported_encodings", (encs.encodings ?? []).length >= 25, encs);

// --- dry run does not write ---
const before = readFileSync(path.join(root, "sub", "a.txt"), "utf8");
const dr = await call("write_file", {
  path: path.join(root, "sub", "a.txt"),
  content: "ZZZ\n",
  dryRun: true,
});
check("dryRun reports", dr.dryRun === true, dr);
check("dryRun wrote nothing", readFileSync(path.join(root, "sub", "a.txt"), "utf8") === before, null);

child.kill();
console.log(`PASS ${ok.length}  FAIL ${fail.length}`);
if (fail.length) {
  for (const f of fail) console.log("  FAIL " + f);
  console.log("stderr:", stderr.trim().split("\n").slice(0, 5).join(" | "));
  process.exit(1);
}

function isUtf8(buf) {
  try {
    new TextDecoder("utf-8", { fatal: true }).decode(buf);
    return true;
  } catch {
    return false;
  }
}
