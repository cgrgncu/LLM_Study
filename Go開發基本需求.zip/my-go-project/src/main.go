package main

import (
	"io"
	"log"
	"os/exec"
	"strings"
	"syscall"
	"unsafe"

	"github.com/lxn/walk"
	"github.com/lxn/win"
)

// 視窗邏輯尺寸（96 DPI 基準），實際像素會依 DPI 等比放大
const (
	winWidth96  = 800
	winHeight96 = 600

	appName    = "my-go-project"
	appVersion = "v20261024a"
	appAuthor  = "HsiupoYeh"
)

// rsrc.syso 產生時，應用程式圖示群組的資源 ID
const appIconResourceID = 2

var (
	prevWndProc uintptr
	wndProcCb   = syscall.NewCallback(mainWndProc)

	// 指令輸入框的視窗程序：吃掉 Enter，避免單行 EDIT 發出提示音
	prevInputWndProc uintptr
	inputWndProcCb   = syscall.NewCallback(inputWndProc)
	onInputEnter     func()

	// 視窗完成定位後才啟用尺寸鎖定，避免建立期間被誤鎖
	sizeLocked bool
)

// inputWndProc 攔截 Enter，交給 onInputEnter 送出指令；
// 同時吞掉 TranslateMessage 產生出來的 WM_CHAR CR，避免系統提示音。
func inputWndProc(hwnd win.HWND, msg uint32, wParam, lParam uintptr) uintptr {
	if msg == win.WM_KEYDOWN && wParam == uintptr(win.VK_RETURN) {
		if onInputEnter != nil {
			onInputEnter()
		}
		return 0
	}
	if msg == win.WM_CHAR && wParam == 13 {
		return 0
	}

	return win.CallWindowProc(prevInputWndProc, hwnd, msg, wParam, lParam)
}

// fixedPixelSize 依目前視窗所在螢幕的 DPI 換算固定尺寸（像素）
func fixedPixelSize(hwnd win.HWND) (int32, int32) {
	dpi := int(win.GetDpiForWindow(hwnd))
	if dpi <= 0 {
		dpi = 96
	}

	w := int32(winWidth96 * dpi / 96)
	h := int32(winHeight96 * dpi / 96)

	return w, h
}

// mainWndProc 攔截系統命令與尺寸限制，徹底禁止最大化與縮放
// （即使沒有 WS_MAXIMIZEBOX，Win+Up 或雙擊標題列仍會送出 SC_MAXIMIZE）。
func mainWndProc(hwnd win.HWND, msg uint32, wParam, lParam uintptr) uintptr {
	switch msg {
	case win.WM_SYSCOMMAND:
		if wParam&0xFFF0 == win.SC_MAXIMIZE {
			return 0
		}

	case win.WM_GETMINMAXINFO:
		ret := win.CallWindowProc(prevWndProc, hwnd, msg, wParam, lParam)
		if sizeLocked && lParam != 0 {
			w, h := fixedPixelSize(hwnd)
			mmi := (*win.MINMAXINFO)(unsafe.Pointer(lParam))
			mmi.PtMinTrackSize = win.POINT{X: w, Y: h}
			mmi.PtMaxTrackSize = win.POINT{X: w, Y: h}
			mmi.PtMaxSize = win.POINT{X: w, Y: h}
		}
		return ret
	}

	return win.CallWindowProc(prevWndProc, hwnd, msg, wParam, lParam)
}

// loadAppIcon 從嵌入資源載入應用程式圖示（找不到時退回常見資源 ID）
func loadAppIcon() *walk.Icon {
	for _, id := range []int{appIconResourceID, 7, 1, 3} {
		if icon, err := walk.NewIconFromResourceId(id); err == nil {
			return icon
		}
	}

	return nil
}

// forceForeground 讓指定視窗成為前景視窗（取得焦點）。
// Windows 會限制非前景程序呼叫 SetForegroundWindow，因此失敗時
// 暫時附加到目前前景執行緒的輸入隊列後再試一次。
func forceForeground(hwnd win.HWND) {
	if hwnd == 0 {
		return
	}

	if win.IsIconic(hwnd) {
		win.ShowWindow(hwnd, win.SW_RESTORE)
	}

	if win.SetForegroundWindow(hwnd) {
		return
	}

	curThread := int32(win.GetCurrentThreadId())
	var fgThread int32
	if fg := win.GetForegroundWindow(); fg != 0 {
		fgThread = int32(win.GetWindowThreadProcessId(fg, nil))
	}

	attached := false
	if fgThread != 0 && fgThread != curThread {
		attached = win.AttachThreadInput(fgThread, curThread, true)
	}

	win.BringWindowToTop(hwnd)
	win.SetActiveWindow(hwnd)
	win.SetForegroundWindow(hwnd)

	if attached {
		win.AttachThreadInput(fgThread, curThread, false)
	}
}

func main() {
	// Bounds 為 96 DPI 邏輯單位，walk 會依 DPI 自動換算成像素
	mw, err := walk.NewMainWindowWithCfg(&walk.MainWindowCfg{
		Bounds: walk.Rectangle{Width: winWidth96, Height: winHeight96},
	})
	if err != nil {
		log.Fatal(err)
	}

	mw.SetTitle(appName + " " + appVersion)

	mainLayout := walk.NewVBoxLayout()
	if err := mainLayout.SetMargins(walk.Margins{}); err != nil {
		log.Println("SetMargins:", err)
	}
	if err := mainLayout.SetSpacing(0); err != nil {
		log.Println("SetSpacing:", err)
	}
	mw.SetLayout(mainLayout)

	// 視窗圖示（標題列／工作列／Alt+Tab），來源為嵌入的 rsrc.syso
	if icon := loadAppIcon(); icon != nil {
		if err := mw.SetIcon(icon); err != nil {
			log.Println("SetIcon:", err)
		}
	}

	// 固定尺寸：移除最大化與縮放邊框
	style := win.GetWindowLong(mw.Handle(), win.GWL_STYLE)
	style &^= win.WS_MAXIMIZEBOX
	style &^= win.WS_THICKFRAME
	win.SetWindowLong(mw.Handle(), win.GWL_STYLE, style)
	win.SetWindowPos(mw.Handle(), 0, 0, 0, 0, 0,
		win.SWP_NOMOVE|win.SWP_NOSIZE|win.SWP_NOZORDER|win.SWP_NOACTIVATE|win.SWP_FRAMECHANGED)

	// 攔截系統命令，禁止最大化
	prevWndProc = win.SetWindowLongPtr(mw.Handle(), win.GWLP_WNDPROC, wndProcCb)

	// 選單：說明(&H) → 關於我(&A)
	helpMenu, err := walk.NewMenu()
	if err != nil {
		log.Fatal(err)
	}
	menuAction := walk.NewMenuAction(helpMenu)
	menuAction.SetText("說明(&H)")
	if err := mw.Menu().Actions().Add(menuAction); err != nil {
		log.Fatal(err)
	}

	aboutAction := walk.NewAction()
	aboutAction.SetText("關於我(&A)")
	aboutAction.Triggered().Attach(func() {
		walk.MsgBox(mw, "說明", "軟體名稱: "+appName+"\n作者: "+appAuthor+"\n版本: "+appVersion, walk.MsgBoxIconInformation)
	})
	if err := helpMenu.Actions().Add(aboutAction); err != nil {
		log.Fatal(err)
	}

	// 內容：兩個分頁，填滿整個視窗
	tab, err := walk.NewTabWidget(mw)
	if err != nil {
		log.Fatal(err)
	}

	// 主程式分頁：上方按鈕列，下方填滿唯讀 MEMO（終端機輸出）
	page1, err := walk.NewTabPage()
	if err != nil {
		log.Fatal(err)
	}
	page1.SetTitle("主程式")

	page1Layout := walk.NewVBoxLayout()
	if err := page1Layout.SetMargins(walk.Margins{}); err != nil {
		log.Println("SetMargins:", err)
	}
	if err := page1Layout.SetSpacing(0); err != nil {
		log.Println("SetSpacing:", err)
	}
	page1.SetLayout(page1Layout)

	btnRow, err := walk.NewComposite(page1)
	if err != nil {
		log.Fatal(err)
	}
	// 按鈕列只佔自然高度，其餘空間全部留給下方 MEMO
	if err := page1Layout.SetStretchFactor(btnRow, 0); err != nil {
		log.Println("SetStretchFactor:", err)
	}
	rowLayout := walk.NewHBoxLayout()
	if err := rowLayout.SetMargins(walk.Margins{HNear: 6, VNear: 6, HFar: 6, VFar: 6}); err != nil {
		log.Println("SetMargins:", err)
	}
	if err := rowLayout.SetSpacing(6); err != nil {
		log.Println("SetSpacing:", err)
	}
	btnRow.SetLayout(rowLayout)

	startBtn, err := walk.NewPushButton(btnRow)
	if err != nil {
		log.Fatal(err)
	}
	startBtn.SetText("啟動終端機")

	clearBtn, err := walk.NewPushButton(btnRow)
	if err != nil {
		log.Fatal(err)
	}
	clearBtn.SetText("清空")

	// 讓按鈕維持自然寬度，多餘空間由水平間隔器吸收
	if _, err := walk.NewHSpacer(btnRow); err != nil {
		log.Fatal(err)
	}

	termMemo, err := walk.NewTextEditWithStyle(page1, win.WS_VSCROLL|win.ES_AUTOVSCROLL)
	if err != nil {
		log.Fatal(err)
	}
	if err := termMemo.SetReadOnly(true); err != nil {
		log.Println("SetReadOnly:", err)
	}
	if f, err := walk.NewFont("Consolas", 10, 0); err == nil {
		termMemo.SetFont(f)
	}

	// 唯讀 EDIT 取得焦點會全選內文：不讓 Tab 停在 MEMO，取得焦點即取消選取
	termMemoStyle := win.GetWindowLong(termMemo.Handle(), win.GWL_STYLE)
	termMemoStyle &^= win.WS_TABSTOP
	win.SetWindowLong(termMemo.Handle(), win.GWL_STYLE, termMemoStyle)
	termMemo.FocusedChanged().Attach(func() {
		if termMemo.Focused() {
			termMemo.SetTextSelection(0, 0)
		}
	})

	// 以下兩個狀態只在 UI 執行緒存取：
	// memoEndsWithNewline 追蹤 MEMO 最後是否為換行；
	// pendingBlankEnter 表示剛送出空白 Enter，下一個 cmd 輸出前要確保先換行。
	var memoEndsWithNewline bool
	var pendingBlankEnter bool

	// 附加文字並自動捲到底部
	appendTermText := func(s string) {
		if s != "" {
			memoEndsWithNewline = strings.HasSuffix(s, "\n")
		}
		termMemo.AppendText(s)
		n := termMemo.TextLength()
		termMemo.SetTextSelection(n, n)
		termMemo.ScrollToCaret()
	}

	// 最底部：指令輸入框 + 送出按鈕
	inputRow, err := walk.NewComposite(page1)
	if err != nil {
		log.Fatal(err)
	}
	if err := page1Layout.SetStretchFactor(inputRow, 0); err != nil {
		log.Println("SetStretchFactor:", err)
	}

	inputLayout := walk.NewHBoxLayout()
	if err := inputLayout.SetMargins(walk.Margins{HNear: 6, VNear: 6, HFar: 6, VFar: 6}); err != nil {
		log.Println("SetMargins:", err)
	}
	if err := inputLayout.SetSpacing(6); err != nil {
		log.Println("SetSpacing:", err)
	}
	inputRow.SetLayout(inputLayout)

	termInput, err := walk.NewLineEdit(inputRow)
	if err != nil {
		log.Fatal(err)
	}
	if f, err := walk.NewFont("Consolas", 10, 0); err == nil {
		termInput.SetFont(f)
	}
	termInput.SetEnabled(false)

	sendBtn, err := walk.NewPushButton(inputRow)
	if err != nil {
		log.Fatal(err)
	}
	sendBtn.SetText("送出")
	if err := inputLayout.SetStretchFactor(sendBtn, 0); err != nil {
		log.Println("SetStretchFactor:", err)
	}
	sendBtn.SetEnabled(false)

	var termRunning bool
	var termStdin io.WriteCloser

	sendCmd := func() {
		if termStdin == nil {
			return
		}
		text := termInput.Text()
		termInput.SetText("")
		termInput.SetFocus()

		line := text + "\r\n"

		// 空白 Enter 也要留下換行；若本機回顯之後仍沒有換行結尾，
		// pump 會在附加 cmd 輸出前補上（見下方 pump）。
		if text == "" {
			pendingBlankEnter = true
		}

		// 本機回顯：看起來就像在終端機輸入
		appendTermText(line)
		_, _ = termStdin.Write([]byte(line))
	}

	sendBtn.Clicked().Attach(sendCmd)

	// 攔截輸入框的 Enter（並阻斷系統提示音）
	onInputEnter = sendCmd
	prevInputWndProc = win.SetWindowLongPtr(termInput.Handle(), win.GWLP_WNDPROC, inputWndProcCb)

	clearBtn.Clicked().Attach(func() {
		termMemo.SetText("")
		memoEndsWithNewline = false
		pendingBlankEnter = false
	})

	startBtn.Clicked().Attach(func() {
		if termRunning {
			return
		}

		cmd := exec.Command("cmd.exe", "/Q", "/K", "chcp 65001>nul")
		cmd.SysProcAttr = &syscall.SysProcAttr{HideWindow: true}

		// 保留 stdin 管線不關閉，否則 cmd 讀到 EOF 會立刻結束
		stdin, err := cmd.StdinPipe()
		if err != nil {
			walk.MsgBox(mw, "錯誤", "無法建立終端機輸入："+err.Error(), walk.MsgBoxIconError)
			return
		}

		stdout, err := cmd.StdoutPipe()
		if err != nil {
			walk.MsgBox(mw, "錯誤", "無法取得終端機輸出："+err.Error(), walk.MsgBoxIconError)
			return
		}
		stderr, err := cmd.StderrPipe()
		if err != nil {
			walk.MsgBox(mw, "錯誤", "無法取得終端機錯誤輸出："+err.Error(), walk.MsgBoxIconError)
			return
		}

		if err := cmd.Start(); err != nil {
			walk.MsgBox(mw, "錯誤", "無法啟動終端機："+err.Error(), walk.MsgBoxIconError)
			return
		}

		termRunning = true
		termStdin = stdin
		startBtn.SetEnabled(false)
		termInput.SetEnabled(true)
		sendBtn.SetEnabled(true)
		termInput.SetFocus()
		appendTermText("=== 終端機已啟動 ===\r\n")

		pump := func(r io.Reader) {
			buf := make([]byte, 4096)
			for {
				n, err := r.Read(buf)
				if n > 0 {
					s := string(buf[:n])
					mw.Synchronize(func() {
						// 空白 Enter 之後，若 MEMO 不是以換行結尾，
						// 先補一個換行，避免 cmd 的提示字元黏在同一行。
						if pendingBlankEnter && !memoEndsWithNewline {
							appendTermText("\r\n")
						}
						pendingBlankEnter = false
						appendTermText(s)
					})
				}
				if err != nil {
					return
				}
			}
		}
		go pump(stdout)
		go pump(stderr)

		go func() {
			err := cmd.Wait()
			mw.Synchronize(func() {
				termRunning = false
				if termStdin != nil {
					_ = termStdin.Close()
					termStdin = nil
				}
				startBtn.SetEnabled(true)
				termInput.SetEnabled(false)
				sendBtn.SetEnabled(false)
				msg := "\r\n=== 終端機已結束"
				if err != nil {
					msg += "：" + err.Error()
				}
				appendTermText(msg + " ===\r\n")
			})
		}()
	})

	// 更新紀錄分頁：唯讀 MEMO
	page2, err := walk.NewTabPage()
	if err != nil {
		log.Fatal(err)
	}
	page2.SetTitle("更新紀錄")

	memoLayout := walk.NewVBoxLayout()
	if err := memoLayout.SetMargins(walk.Margins{}); err != nil {
		log.Println("SetMargins:", err)
	}
	if err := memoLayout.SetSpacing(0); err != nil {
		log.Println("SetSpacing:", err)
	}
	page2.SetLayout(memoLayout)

	memo, err := walk.NewTextEditWithStyle(page2, win.WS_VSCROLL|win.ES_AUTOVSCROLL)
	if err != nil {
		log.Fatal(err)
	}
	memo.SetText("軟體名稱：" + appName + "\r\n作者：" + appAuthor + "\r\n目前版本：" + appVersion + "\r\n\r\n更新紀錄：\r\nv20261024:初版\r\n")
	if err := memo.SetReadOnly(true); err != nil {
		log.Println("SetReadOnly:", err)
	}

	// 唯讀 EDIT 取得焦點時 Windows 會自動全選內文：
	// 不讓 Tab 鍵停在 MEMO，且一取得焦點就取消選取。
	memoStyle := win.GetWindowLong(memo.Handle(), win.GWL_STYLE)
	memoStyle &^= win.WS_TABSTOP
	win.SetWindowLong(memo.Handle(), win.GWL_STYLE, memoStyle)

	memo.FocusedChanged().Attach(func() {
		if memo.Focused() {
			memo.SetTextSelection(0, 0)
		}
	})

	if err := tab.Pages().Add(page1); err != nil {
		log.Fatal(err)
	}
	if err := tab.Pages().Add(page2); err != nil {
		log.Fatal(err)
	}

	// 切換分頁後把焦點放回主視窗
	tab.CurrentIndexChanged().Attach(func() {
		if tab.CurrentIndex() == 1 {
			memo.SetTextSelection(0, 0)
		}
		win.SetFocus(mw.Handle())
	})

	// 視窗啟動後（訊息迴圈已就緒）定位、鎖尺寸並搶焦點
	mw.Starting().Attach(func() {
		mw.Show()

		hwnd := mw.Handle()

		// 依 DPI 換算實際像素尺寸，並在實體螢幕上置中
		w, h := fixedPixelSize(hwnd)
		screenW := int32(win.GetSystemMetrics(win.SM_CXSCREEN))
		screenH := int32(win.GetSystemMetrics(win.SM_CYSCREEN))
		_ = mw.SetBoundsPixels(walk.Rectangle{
			X:      int((screenW - w) / 2),
			Y:      int((screenH - h) / 2),
			Width:  int(w),
			Height: int(h),
		})

		sizeLocked = true

		forceForeground(hwnd)

		// 啟動時把焦點放回主視窗
		win.SetFocus(hwnd)
	})

	mw.Run()
}
