@echo off
cd /d "%~dp0src"
go build -mod=vendor -ldflags="-H=windowsgui" -o ..\exe\my-go-project.exe
if errorlevel 1 (
    echo Build failed.
    exit /b 1
)
echo Build complete: ..\exe\my-go-project.exe
