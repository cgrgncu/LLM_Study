﻿my-go-project - Windows 終端機視窗應用程式

作者: HsiupoYeh
版本: v20261024a

使用 lxn/walk GUI 庫（原生 Windows API，純 Go，無需 CGO）
GitHub: https://github.com/lxn/walk

建置環境:
- Go 1.23.4 以上（go.mod 宣告 go 1.23.4）
- 依賴已放入 src/vendor，可完全離線編譯

功能:
- 視窗尺寸：800x600（96 DPI 邏輯單位，實際像素依 DPI 等比放大）
- 固定尺寸，不可拖拉縮放、不可最大化（僅最小化／關閉）
- 視窗置中顯示（依實體螢幕解析度與目前 DPI 計算）
- 支援 DPI：manifest 宣告 PerMonitorV2，視窗與字型隨螢幕 DPI 縮放
- 啟動後視窗自動取得焦點（前景視窗）
- 圖示：icon/my-go-project.ico，以 rsrc.syso 嵌入（資源群組 ID = 2）
- 選單列：「說明(&H)」→「關於我(&A)」（Alt+H / Alt+A）
- 主視窗內容：兩個分頁（Tab），填滿整個客戶區
  - 主程式：內嵌 cmd.exe 終端機
    - 「啟動終端機」啟動 cmd.exe（UTF-8，隱藏主控台視窗）
    - 「清空」清除終端機輸出
    - 唯讀輸出 MEMO，自動捲到底部
    - 指令輸入框 + 「送出」按鈕，Enter 可直接送出
    - 空白 Enter 也會正確換行
    - 保留 stdin 管線，避免 cmd 讀到 EOF 立刻結束
  - 更新紀錄：唯讀 MEMO，顯示目前版本與更新內容
- 無 Status Bar
- 無 console 視窗（GUI 應用程式）

目錄結構:
  my-go-project/
  ├── src/
  │   ├── main.go         ← 原始碼入口（慣例使用 main.go 作為固定名稱）
  │   ├── go.mod          ← 模組定義（記錄套件版本，有助追蹤與重建環境）
  │   ├── go.sum          ← 依賴 hash 鎖定（vendor 時產生）
  │   ├── vendor/         ← 所有依賴原始碼（離線編譯用；完全離線、可分發；遵守來源版權）
  │   │   ├── github.com/
  │   │   ├── golang.org/
  │   │   ├── gopkg.in/
  │   │   └── modules.txt
  │   ├── rsrc.syso       ← 資源檔（圖示 + manifest，用 rsrc 工具產生）
  │   └── main.manifest   ← DPI awareness + 視覺樣式設定（嵌入 rsrc.syso）
  ├── icon/
  │   └── my-go-project.ico  ← 應用程式圖示
  ├── exe/
  │   └── my-go-project.exe  ← 編譯後的執行檔
  ├── build.bat           ← 編譯腳本
  ├── backup/             ← 手動備份（取代 Git）
  └── README.md           ← 專案說明（可選）

編譯方式:
  build.bat
  或
  cd src && go build -mod=vendor -ldflags="-H=windowsgui" -o ..\exe\my-go-project.exe

編譯輸出:
  exe/my-go-project.exe（含圖示 + manifest）

產生 rsrc.syso:
  rsrc -ico icon/my-go-project.ico -manifest src/main.manifest -o src/rsrc.syso
